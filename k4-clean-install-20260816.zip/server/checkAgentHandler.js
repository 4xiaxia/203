import { parseCheckAgentResponse } from '../src/check-agent/contract.js'
import {
  isOptions,
  readJsonBody,
  requestChatCompletion,
  resolveUserCredentials,
  sendJson,
  getChatMessageText,
} from './http.js'

const CHECK_REFERENCE = [
  '这是第二双眼睛，不是审核门槛。保留当前题目的事实、解题结论、孩子能跟上的推理路径；不要把讲解压成标准答案。',
  '前述规则都是润色参照，不是验收条件。数字、标签、断句或语气有一处漏转，或你拿不准怎样改时，保留原句继续交付；绝不因此拒绝、删减、留空或卡住整张表。始终返回完整当前五字段，changes 只记录你实际做出的温和改动。',
  '把整张表从第一行到最后一行逐行走读，不要只挑最显眼的一处。每一行都问自己：这句像孩子身边的老师吗？它有没有接住上一行已经得到的东西，并把孩子带向下一小步？这行 speech、board 和 actionSpec 是否在同一个教学瞬间？发现更自然、更清楚、更能陪孩子想下去的说法时，就温柔改好并记录 changes。已经贴切的行原样保留，绝不为了凑数量硬改。',
  '固定仪式必须保住：第一行开场使用“同学你好！很高兴为你讲解这道题。”、“我们来看这道题。”，或能准确概括题型时的“好的，我们来看一道关于……的题目，准备好了吗？”；最后一行结束使用“路虽远，行则将至，加油！”或“这道题就讲到这里，再见！”。',
  '检查并消除机械腔、产品说明腔和居高临下的口气。禁止“说白了、显而易见、很简单、大家看、你这都不会、这还不明白、来我告诉你”；禁止“定个性、建模型、预解、推导依据、总目标、最小必要条件”等教案元语言；禁止重复题干、夸张表扬、表情符号和“记住了啊、听好了、你要注意”等命令语气。',
  '口播风格是“李永乐老师的严谨逻辑 + 启蒙幼师的亲和引导”，自然流畅，不过度夸张。润色时保住共建感：自然使用“我们、咱们、一起、呢、呀、哈、是不是、对不对”，让孩子觉得老师在身边同行，不是在发号施令。',
  '把思考过程说出来：列式前讲清题目条件怎样连到学过的关系；试错时可以坦诚“我猜可能是这样，但算一下发现不对，那我们再换个思路”；算式必须念成人话。每一步结论后可自然确认，问题后留出 [pause]，但不假装真的等待回答。',
  '让稿子像人在呼吸：关键点、转弯处、结论后有自然停顿；用“那、好、接下来”自然衔接；需要板书时，口播的是孩子此刻看懂了什么，不念动作说明。',
  '四环一体按固定顺序缺一不可：递归拆解给出从总问题到小问题的起点；预设问题、自问自答和错误预判先接住遗忘或误解；问题链以递进式为主，后一个问题必须接住前一个答案，不把零散设问并排堆放；筛网归题把旧知识 callback 到本题，并留下下次遇到同类题能怎么想。发现表达被压扁时，只在现有对应 speech 内温柔补足，不增加、删除或重排行。',
  '知识 callback 不是术语装饰。孩子可能忘记乘法事实、面积公式或数量关系，也可能不知道条件怎样用；先在本题里找回相关旧知识并解释意思，再带他使用，不能假定孩子已经会。',
  'speech 是给第三方 TTS 的原稿，优先润色它：一句只承载一个清楚的思考动作，可在同一个 speech 字符串内用换行或自然标点断句。保留温柔、同行、启发式语气；把数学符号、公式语法改成可朗读中文。',
  'speech 里的所有数字都按中文口语写，不能把阿拉伯数字串交给 TTS。例：1400000 写“一百四十万”，14000 写“一万四千”，3.14 写“三点一四”，0.05 写“零点零五”，5/8 写“八分之五”，1又1/2 写“一又二分之一”。未知数读“艾克斯”，乘法读“乘以”。这条只作用于 speech，board 保留它自己的数学书写。',
  '按语义少量加入并保留 TTS 标签：孩子思考、转弯、关键结论后用 [pause]；发现规律、恍然大悟时用 [excited]；知识点、关键条件、数量关系、单位等需要听清的词用 [emphasis]。不要给每句都加标签，不要把标签放进 board 或 actionSpec。',
  '只在确有讲解不一致时修正 board；只在 speech 改动造成 cueText 不再对应、或动作坐标排版确有问题时修正 actionSpec。',
  '不检查 Agent A/B 生成过程，不读取外部文档，不修改步骤数、顺序、duration、stage。',
].join('\n')

function toCheckContractRow(row) {
  return {
    duration: row?.duration || '待程序预估',
    stage: row?.stage,
    speech: row?.speech,
    board: row?.board,
    actionSpec: row?.actionSpec,
  }
}

export async function handleCheckAgentRequest(req, res) {
  if (isOptions(req, res)) return true
  if (req.method !== 'POST') return false

  try {
    const body = await readJsonBody(req)
    let credentials
    try {
      credentials = resolveUserCredentials(body)
    } catch (error) {
      return sendJson(req, res, 400, { ok: false, error: error.message })
    }
    if (!Array.isArray(body.currentRows) || !body.currentRows.length) {
      return sendJson(req, res, 400, { ok: false, error: '没有可检查的 Agent B 生成内容' })
    }
    const currentRows = body.currentRows.map(toCheckContractRow)

    const userContent = [{
      type: 'text',
      text: `【用户点击 Check 时的当前五字段】\n${JSON.stringify(currentRows, null, 2)}`,
    }]

    const { response, data } = await requestChatCompletion({
      ...credentials,
      timeoutMs: 90000,
      body: {
        temperature: 0.2,
        stream: false,
        response_format: { type: 'json_object' },
        messages: [
          {
            role: 'system',
            content: [
              '你是独立的 Check Agent，不是 Agent B，也不负责生成内容。',
              '你的唯一业务输入是用户点击 Check 时提交的当前五字段。用户可能已经手动修改过；只以这次提交的内容为准，不追溯 Agent A、Agent B 或生成过程。',
              '只按 CHECK_REFERENCE 润色当前表，不使用 Agent B 生成提示词。',
              '只允许修正 speech、board，以及坐标排版所必需的 actionSpec。duration、stage 必须原样保留，步骤数量和顺序不得改变。',
              CHECK_REFERENCE,
              '必须返回 JSON 对象：{"rows":[完整修正后五字段],"changes":[{"row":行号,"field":"字段名","before":"原文","after":"修正后","reason":"修正原因"}]}。',
              '即使没有问题，也要原样返回完整 rows，并返回 changes:[]。不要只写检查报告。',
            ].join('\n\n'),
          },
          { role: 'user', content: userContent },
        ],
      },
    })
    if (!response.ok) {
      return sendJson(req, res, response.status, {
        ok: false,
        error: data?.error?.message || data?.message || `Check Agent 上游失败 ${response.status}`,
      })
    }

    const text = getChatMessageText(data?.choices?.[0]?.message)
    const parsed = parseCheckAgentResponse(text, currentRows)
    if (!parsed.ok) {
      // Check is optional polish. A malformed polish reply must never block B's usable table.
      return sendJson(req, res, 200, {
        ok: true,
        model: credentials.model,
        rows: currentRows,
        changes: [],
        usage: data?.usage || null,
      })
    }
    return sendJson(req, res, 200, {
      ok: true,
      model: credentials.model,
      rows: parsed.value.rows,
      changes: parsed.value.changes,
      usage: data?.usage || null,
    })
  } catch (error) {
    const status = error?.name === 'AbortError' ? 504 : 500
    return sendJson(req, res, status, {
      ok: false,
      error: error?.name === 'AbortError'
        ? 'Check Agent 上游连续两次请求均超时（单次 90 秒）'
        : error?.message || String(error),
    })
  }
}

export function checkAgentProxyPlugin() {
  return {
    name: 'check-agent-proxy',
    configureServer(server) {
      server.middlewares.use('/api/check-agent/check', (req, res, next) => {
        Promise.resolve(handleCheckAgentRequest(req, res)).then((handled) => {
          if (!handled) next()
        }).catch(next)
      })
    },
  }
}
