import { AGENT_B_V2_SYSTEM_PROMPT } from '../src/agent-b-v2/prompt.js'
import { parseAgentBV2Response } from '../src/agent-b-v2/contract.js'
import {
  isOptions,
  readJsonBody,
  requestAnthropicMessage,
  requestChatCompletion,
  resolveUserCredentials,
  sendJson,
  getChatMessageText,
} from './http.js'

const AGENT_B_SYSTEM_MESSAGE = AGENT_B_V2_SYSTEM_PROMPT
const RAW_IMAGE_FIELDS = new Set(['problemImage', 'sourceImageDataUrl', 'previewDataUrl', 'imageDataUrl'])

function toAgentBPromptHandoff(payload = {}) {
  return Object.fromEntries(
    Object.entries(payload).filter(([key]) => !RAW_IMAGE_FIELDS.has(key)),
  )
}

function toAnthropicContent(content) {
  return content.flatMap((item) => {
    if (item.type === 'text') return [{ type: 'text', text: item.text }]
    const url = item.image_url?.url
    const dataUrl = typeof url === 'string' && url.match(/^data:([^;]+);base64,(.+)$/)
    if (dataUrl) {
      return [{
        type: 'image',
        source: { type: 'base64', media_type: dataUrl[1], data: dataUrl[2] },
      }]
    }
    if (typeof url === 'string') {
      return [{ type: 'image', source: { type: 'url', url } }]
    }
    return []
  })
}

export async function handleAgentBV2Request(req, res) {
  if (isOptions(req, res)) return true
  if (req.method !== 'POST') return false

  try {
    const body = await readJsonBody(req)
    let credentials
    try {
      credentials = resolveUserCredentials(body)
    } catch (error) {
      return sendJson(req, res, 400, {
        ok: false,
        error: error.message,
      })
    }
    const handoff = body.handoff || {}
    const promptHandoff = toAgentBPromptHandoff(handoff)
    const userContent = [
      { type: 'text', text: `【Agent A handoff】\nfile: handoff.json\n${JSON.stringify(promptHandoff, null, 2)}` },
    ]
    const problemImage = handoff.problemImage || handoff.sourceImageDataUrl
    if (problemImage) {
      userContent.push(
        { type: 'text', text: '【题目图片】以下图片是 Agent A 交接的题目信息。' },
        { type: 'image_url', image_url: { url: problemImage } },
      )
    }
    if (handoff.previewDataUrl) {
      userContent.push(
        { type: 'text', text: '【网格画布快照】这是生成网格后的完整画布快照，用于看布局。' },
        { type: 'image_url', image_url: { url: handoff.previewDataUrl } },
      )
    }

    const isAnthropic = body.apiType === 'anthropic-messages'
    const { response, data } = isAnthropic
      ? await requestAnthropicMessage({
          ...credentials,
          timeoutMs: 90000,
          body: {
            system: AGENT_B_SYSTEM_MESSAGE,
            max_tokens: 8192,
            temperature: Number(body.temperature ?? 0.7),
            messages: [{ role: 'user', content: toAnthropicContent(userContent) }],
          },
        })
      : await requestChatCompletion({
          ...credentials,
          timeoutMs: 90000,
          body: {
            temperature: Number(body.temperature ?? 0.7),
            stream: false,
            response_format: { type: 'json_object' },
            messages: [
              { role: 'system', content: AGENT_B_SYSTEM_MESSAGE },
              { role: 'user', content: userContent },
            ],
          },
        })
    if (!response.ok) {
      return sendJson(req, res, response.status, {
        ok: false,
        error: data?.error?.message || data?.message || `上游失败 ${response.status}`,
      })
    }

    const text = isAnthropic
      ? getChatMessageText(data)
      : getChatMessageText(data?.choices?.[0]?.message)
    const parsed = parseAgentBV2Response(text, {
      problemType: handoff?.problemType,
    })
    if (!parsed.ok) {
      return sendJson(req, res, 422, {
        ok: false,
        code: 'AGENT_B_V2_CONTRACT_INVALID',
        error: parsed.error,
        finishReason: data?.stop_reason || data?.choices?.[0]?.finish_reason || '',
        usage: data?.usage || null,
        diagnostic: { rawTextHead: text.slice(0, 500) },
      })
    }
    return sendJson(req, res, 200, {
      ok: true,
      model: credentials.model,
      rows: parsed.value,
      finishReason: data?.stop_reason || data?.choices?.[0]?.finish_reason || '',
      usage: data?.usage || null,
    })
  } catch (error) {
    const status = error?.name === 'AbortError' ? 504 : 500
    return sendJson(req, res, status, {
      ok: false,
      error: error?.name === 'AbortError' ? 'Agent B 上游连续两次请求均超时（单次 90 秒）' : error?.message || String(error),
    })
  }
}

export function agentBV2ProxyPlugin() {
  return {
    name: 'agent-b-v2-direct-proxy',
    configureServer(server) {
      server.middlewares.use('/api/agent-b-v2/generate', (req, res, next) => {
        Promise.resolve(handleAgentBV2Request(req, res)).then((handled) => {
          if (!handled) next()
        }).catch(next)
      })
    },
  }
}
