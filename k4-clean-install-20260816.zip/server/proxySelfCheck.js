import assert from 'node:assert/strict'
import { handleAgentBV2Request } from './agentBV2Handler.js'
import { handleCheckAgentRequest } from './checkAgentHandler.js'
import { handleRecognitionRequest } from './recognitionHandler.js'
import { buildSpeechMarkdown } from '../src/lib/speechMarkdown.js'
import { validateAgentBV2Rows } from '../src/agent-b-v2/contract.js'
import { getAgentBDirectorView } from '../src/board-tools/boardToolCatalog.js'

function mockResponse() {
  const headers = new Map()
  return {
    headers,
    statusCode: 0,
    body: '',
    setHeader(key, value) { headers.set(key, value) },
    end(value = '') { this.body = value },
  }
}

process.env.CORS_ORIGINS = 'https://frontend.example'
let response = mockResponse()
await handleAgentBV2Request({ method: 'POST', headers: { origin: 'https://frontend.example' }, body: {} }, response)
assert.equal(response.statusCode, 400)
assert.equal(response.headers.get('Access-Control-Allow-Origin'), 'https://frontend.example')

response = mockResponse()
await handleRecognitionRequest({ method: 'POST', headers: { origin: 'https://other.example' }, body: {} }, response)
assert.equal(response.statusCode, 400)
assert.equal(response.headers.has('Access-Control-Allow-Origin'), false)

process.env.UPSTREAM_HOSTS = 'api.allowed.example'
response = mockResponse()
await handleAgentBV2Request({
  method: 'POST',
  headers: {},
  body: { apiKey: 'test', endpoint: 'https://api.blocked.example/v1', model: 'test' },
}, response)
assert.equal(response.statusCode, 400)
assert.match(response.body, /UPSTREAM_HOSTS/)

const originalFetch = globalThis.fetch
let upstreamRequest
let upstreamUrl
let upstreamCallCount = 0
let failFirstRequest = true
const upstreamRows = [
  { duration: '待程序预估', stage: '题目', speech: '我们先读题。', board: '', actionSpec: [] },
  { duration: '待程序预估', stage: '分析', speech: '我们开始分析。', board: '分析内容', actionSpec: [] },
  { duration: '待程序预估', stage: '分析', speech: '我们继续分析。', board: '继续分析', actionSpec: [] },
]
globalThis.fetch = async (url, options) => {
  upstreamCallCount += 1
  upstreamUrl = String(url)
  upstreamRequest = JSON.parse(options.body)
  if (failFirstRequest) {
    failFirstRequest = false
    return new Response(JSON.stringify({ error: { message: 'temporary upstream failure' } }), {
      status: 503,
      headers: { 'Content-Type': 'application/json' },
    })
  }
  if (options.headers['x-api-key']) {
    return new Response(JSON.stringify({
      content: [{ type: 'text', text: JSON.stringify({ rows: upstreamRows }) }],
      stop_reason: 'end_turn',
    }), { status: 200, headers: { 'Content-Type': 'application/json' } })
  }
  const isCheck = upstreamRequest.messages?.[0]?.content?.includes('独立的 Check Agent')
  const isRecognition = upstreamRequest.messages?.[0]?.content?.[0]?.text?.includes('Agent A 题目识别与知识点检索助手')
  return new Response(JSON.stringify({
    choices: [{
      message: {
        content: JSON.stringify(isRecognition
          ? {
              problemText: '计算8+5，用凑十法讲解',
              problemType: 'calculation',
              boardFocus: 'calculation_process',
              imageKind: 'text_only',
              keepOriginal: false,
              uncertainItems: [],
              suggestedLayout: { layout: 'left_right' },
              knowledgeAnalysis: {
                suggestedGrade: '一年级',
                coreKnowledge: [{ knowledgeId: 'kp_1' }],
                teachingFocus: '理解凑十',
                keyFormulaList: ['8+2+3=13'],
              },
            }
          : isCheck
          ? {
              rows: upstreamRows.map((row, index) => ({
                ...row,
                duration: '预计 0:00—0:05',
                ...(index === 0
                  ? { stage: '总结' }
                  : index === 1
                    ? { speech: '我们开始分析并回顾公式。' }
                    : {}),
              })),
              changes: [{ row: 2, field: 'speech', before: '开始分析。', after: '我们开始分析。', reason: '补足自然口播' }],
            }
          : { rows: upstreamRows }),
      },
    }],
  }), { status: 200, headers: { 'Content-Type': 'application/json' } })
}
try {
  response = mockResponse()
  await handleAgentBV2Request({
    method: 'POST',
    headers: {},
    body: {
      apiKey: 'test',
      endpoint: 'https://api.allowed.example/v1',
      model: 'test',
      handoff: {
        problemText: '1加1等于多少？',
        problemImage: 'data:image/png;base64,PROBLEM',
        sourceImageDataUrl: 'data:image/png;base64,SOURCE',
        previewDataUrl: 'data:image/png;base64,PREVIEW',
        imageDataUrl: 'data:image/png;base64,IMAGE',
      },
    },
  }, response)
  assert.equal(response.statusCode, 200)
  assert.equal(upstreamCallCount, 2)
  const firstAgentBContent = upstreamRequest.messages[1].content
  assert.equal(firstAgentBContent.filter((item) => item.type === 'image_url').length, 2)
  assert.equal(firstAgentBContent[2].image_url.url, 'data:image/png;base64,PROBLEM')
  assert.match(firstAgentBContent[3].text, /网格画布快照/)
  assert.equal(firstAgentBContent[4].image_url.url, 'data:image/png;base64,PREVIEW')

  response = mockResponse()
  await handleAgentBV2Request({
    method: 'POST',
    headers: {},
    body: {
      apiKey: 'test',
      endpoint: 'https://api.allowed.example',
      model: 'claude-sonnet-4-6',
      apiType: 'anthropic-messages',
      handoff: {
        problemImage: 'data:image/png;base64,PROBLEM',
        previewDataUrl: 'data:image/png;base64,PREVIEW',
      },
    },
  }, response)
  assert.equal(response.statusCode, 200)
  assert.equal(upstreamUrl, 'https://api.allowed.example/v1/messages')
  assert.match(upstreamRequest.system, /你是夏夏老师的AI助教/)
  assert.equal(upstreamRequest.messages[0].content.filter((item) => item.type === 'image').length, 2)
  assert.equal(upstreamRequest.messages[0].content[2].source.data, 'PROBLEM')

  const recognitionRequest = {
    method: 'POST',
    headers: {},
    body: {
      apiKey: 'test',
      endpoint: 'https://api.allowed.example/v1',
      model: 'test',
      problemText: '计算8+5，用凑十法讲解',
    },
  }
  const knowledgeBase = (await import('./docReferences.js')).AGENT_A_KNOWLEDGE_BASE
  response = mockResponse()
  await handleRecognitionRequest(recognitionRequest, response, { knowledgeBase })
  assert.equal(response.statusCode, 200)
  assert.match(upstreamRequest.messages[0].content[0].text, /Top-K 精确检索/)
  assert.match(upstreamRequest.messages[0].content[0].text, /rawKnowledgeRecord 由服务端按有效 knowledgeId 完整回填/)
  const recognitionBody = JSON.parse(response.body)
  assert.equal(recognitionBody.knowledgeRetrieval.mode, 'top-k')
  assert.equal(recognitionBody.result.knowledgeAnalysis.coreKnowledge[0].knowledgeId, 'kp_1')
  assert.equal(recognitionBody.result.knowledgeAnalysis.coreKnowledge[0].rawKnowledgeRecord.编号, 'kp_1')
  assert.equal(recognitionBody.cached, false)
  const callsAfterRecognition = upstreamCallCount

  response = mockResponse()
  await handleRecognitionRequest(recognitionRequest, response, { knowledgeBase })
  assert.equal(response.statusCode, 200)
  assert.equal(JSON.parse(response.body).cached, true)
  assert.equal(upstreamCallCount, callsAfterRecognition, '相同 Agent A 请求不应重复调用付费上游')

  response = mockResponse()
  await handleAgentBV2Request({
    method: 'POST',
    headers: {},
    body: {
      apiKey: 'test',
      endpoint: 'https://api.allowed.example/v1',
      model: 'test',
      handoff: { sourceImageDataUrl: 'data:image/png;base64,AA==' },
    },
  }, response)
  assert.equal(response.statusCode, 200)
  assert.equal(upstreamRequest.messages[1].content.some((item) => item.type === 'image_url'), true)

  response = mockResponse()
  const timedRows = upstreamRows.map((row) => ({
    ...row,
    duration: '预计 0:00—0:05',
    timingStatus: 'estimated',
    estimatedDurationMs: 5000,
  }))
  await handleCheckAgentRequest({
    method: 'POST',
    headers: {},
    body: {
      apiKey: 'test',
      endpoint: 'https://api.allowed.example/v1',
      model: 'test',
      currentRows: timedRows,
      handoff: {
        problemText: '1加1等于多少？',
        previewDataUrl: 'data:image/png;base64,PREVIEW',
      },
    },
  }, response)
  assert.equal(response.statusCode, 200)
  assert.match(upstreamRequest.messages[0].content, /前述规则都是润色参照，不是验收条件/)
  assert.match(upstreamRequest.messages[0].content, /speech 是给第三方 TTS 的原稿/)
  assert.match(upstreamRequest.messages[0].content, /不读取外部文档/)
  assert.doesNotMatch(upstreamRequest.messages[0].content, /doc\/key\.md/)
  assert.match(upstreamRequest.messages[1].content[0].text, /用户点击 Check 时的当前五字段/)
  assert.equal(upstreamRequest.messages[1].content.some((item) => item.type === 'image_url'), false)
  const checkBody = JSON.parse(response.body)
  assert.equal(checkBody.changes.length, 1)
  assert.equal(checkBody.changes[0].field, 'speech')
  assert.equal(checkBody.rows[0].duration, '预计 0:00—0:05')
  assert.equal(Object.hasOwn(checkBody.rows[0], 'timingStatus'), false)
  assert.equal(checkBody.rows[0].stage, upstreamRows[0].stage)
  assert.equal(Object.hasOwn(checkBody.rows[0], 'notes'), false)

  response = mockResponse()
  await handleAgentBV2Request({
    method: 'POST',
    headers: {},
    body: {
      apiKey: 'test',
      endpoint: 'https://api.allowed.example/v1',
      model: 'test',
      handoff: { problemText: '1加1等于多少？' },
    },
  }, response)
  assert.equal(response.statusCode, 200)
  assert.equal(upstreamRequest.messages[0].content.includes('【doc/'), false)
  assert.equal(upstreamRequest.messages[0].content.includes('.md】'), false)
  assert.equal(upstreamRequest.messages[0].content.includes('.csv】'), false)
  assert.match(upstreamRequest.messages[1].content[0].text, /^【Agent A handoff】/)
  assert.equal(upstreamRequest.messages[1].content.length, 1)
  assert.equal(upstreamRequest.messages[1].content[0].type, 'text')
  assert.doesNotMatch(upstreamRequest.messages[1].content[0].text, /data:image\/png;base64/)
  assert.doesNotMatch(upstreamRequest.messages[1].content[0].text, /sourceImageDataUrl|previewDataUrl|imageDataUrl|problemImage/)
} finally {
  globalThis.fetch = originalFetch
}

const markdown = buildSpeechMarkdown(upstreamRows, { problemText: '1加1等于多少？', model: 'test' })
assert.equal(markdown, '我们先读题。\n\n我们开始分析。\n\n我们继续分析。\n')

const directorTools = getAgentBDirectorView().tools.map((tool) => tool.id)
assert.equal(directorTools.includes('draw'), false, 'Agent B 不应看到 runtime 无法执行的 draw 工具')
assert.equal(directorTools.includes('rough-line'), true)

const actionRows = [
  { duration: '待程序预估', stage: '题目', speech: '我们先读题。', board: '', actionSpec: [] },
  {
    duration: '待程序预估',
    stage: '分析',

    speech: '我们画一条辅助线。',
    board: '辅助线',
    actionSpec: [{
      cueText: '画一条辅助线',
      action: {
        tool: 'rough-line',
        region: 'analysis',
        start: [220, 520],
        end: [520, 520],
        order: 1,
        style: { colorId: 'blue', strokeWidthId: 'normal' },
      },
    }],
  },
]
assert.equal(validateAgentBV2Rows(actionRows, { problemType: 'geometry' }).ok, true)
assert.equal(validateAgentBV2Rows(actionRows.map((row, index) => index === 1
  ? { ...row, actionSpec: [{ cueText: '不存在的口播', action: row.actionSpec[0].action }] }
  : row), { problemType: 'geometry' }).ok, true)
const missingCueRows = actionRows.map((row, index) => index === 1
  ? { ...row, actionSpec: [{ action: row.actionSpec[0].action }] }
  : row)
const normalizedMissingCue = validateAgentBV2Rows(missingCueRows, { problemType: 'geometry' })
assert.equal(normalizedMissingCue.ok, true)
assert.equal(normalizedMissingCue.value[1].actionSpec[0].cueText, 'rough-line')
const invalidActionRows = validateAgentBV2Rows(actionRows.map((row, index) => index === 1
  ? { ...row, actionSpec: [{ cueText: '画一条辅助线', action: { tool: 'draw', region: 'analysis', order: 1 } }] }
  : row), { problemType: 'geometry' })
assert.equal(invalidActionRows.ok, true)
assert.deepEqual(invalidActionRows.value[1].actionSpec, [])

console.log('proxy self-check ok')
