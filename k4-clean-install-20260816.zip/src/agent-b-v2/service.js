/* @qh-core LANE=B-V2 POINT=CLIENT_GENERATE buildPayload+fetch /api/agent-b-v2/generate
 * Agent B 使用独立配置，不与 Agent A / C 共用模型或 API。
 */
import { applyAgentBV2Timeline } from './timing.js'
import { getAgentBApiSnapshot } from '../lib/agentBApiConfig.js'

const GENERATION_TEMPERATURE = 0.8

export async function generateAgentBV2Rows({ handoff }) {
  const userSnap = getAgentBApiSnapshot()
  if (!userSnap.apiKey) {
    throw new Error('缺少 Agent B API Key：请先在前端「Agent 配置」里填写')
  }
  if (!userSnap.endpoint) {
    throw new Error('缺少 Agent B endpoint：请先在前端「Agent 配置」里填写上游 API URL')
  }
  if (!userSnap.model) {
    throw new Error('缺少 Agent B model：请先在前端「Agent 配置」里填写模型名')
  }
  const controller = new AbortController()
  const timeoutId = window.setTimeout(() => controller.abort(), 185000)
  let response
  let data
  try {
    response = await fetch('/api/agent-b-v2/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        temperature: GENERATION_TEMPERATURE,
        endpoint: userSnap.endpoint,
        model: userSnap.model,
        apiKey: userSnap.apiKey,
        apiType: userSnap.apiType,
        handoff,
      }),
    })
    data = await response.json().catch(() => ({}))
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('Agent B 连续两次请求均超时，已取消')
    throw error
  } finally {
    window.clearTimeout(timeoutId)
  }

  if (!response.ok || !data.ok) throw new Error(data.error || `Agent B 生成失败 ${response.status}`)
  const rows = applyAgentBV2Timeline(data.rows)
  return {
    rows,
    model: data.model || userSnap.model,
    usage: data.usage || null,
  }
}
