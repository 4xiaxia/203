/* @qh-core LANE=B-V2 POINT=CONTRACT_NORMALIZE model rows into board-readable fields */
import { validateBoardToolAction } from '../board-tools/boardToolCatalog.js'
export const AGENT_B_V2_COLUMNS = Object.freeze([
  'duration',
  'stage',
  'speech',
  'board',
  'actionSpec',
])

export const AGENT_B_V2_STAGES = Object.freeze(['题目', '分析', '解答', '总结'])
function isRecord(value) {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value)
}

function normalizeStage(stage, index) {
  if (AGENT_B_V2_STAGES.includes(stage)) return stage
  return index === 0 ? '题目' : '分析'
}

function parseJsonObject(text) {
  const source = String(text || '').trim()
  const fenced = source.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim()
  const candidate = fenced || source
  try {
    return JSON.parse(candidate)
  } catch {
    const start = candidate.indexOf('{')
    const end = candidate.lastIndexOf('}')
    if (start < 0 || end <= start) return null
    try {
      return JSON.parse(candidate.slice(start, end + 1))
    } catch {
      return null
    }
  }
}

function normalizeActionCueText(entry) {
  const explicit = typeof entry?.cueText === 'string' ? entry.cueText.trim() : ''
  if (explicit) return explicit
  const action = entry?.action || {}
  if (typeof action.content === 'string' && action.content.trim()) return action.content.trim()
  if (typeof action.target?.exactText === 'string' && action.target.exactText.trim()) {
    return action.target.exactText.trim()
  }
  if (typeof entry?.capabilityGap?.need === 'string' && entry.capabilityGap.need.trim()) {
    return entry.capabilityGap.need.trim()
  }
  return typeof action.tool === 'string' && action.tool ? action.tool : '板书动作'
}

export function normalizeAgentBV2ActionSpec(actionSpec) {
  return (Array.isArray(actionSpec) ? actionSpec : []).flatMap((entry) => {
    if (!isRecord(entry)) return []
    if (entry.capabilityGap) return [{ ...entry, cueText: normalizeActionCueText(entry) }]

    const action = validateBoardToolAction(entry.action)
    if (!action.ok) return []
    return [{ ...entry, action: action.value, cueText: normalizeActionCueText(entry) }]
  })
}

export function normalizeAgentBV2BoardCells(rows) {
  return (Array.isArray(rows) ? rows : []).flatMap((row, index) => {
    if (!isRecord(row)) return []
    return [{
      duration: typeof row.duration === 'string' ? row.duration : '待程序预估',
      stage: normalizeStage(row.stage, index),
      speech: typeof row.speech === 'string' ? row.speech : '',
      board: typeof row.board === 'string' ? row.board : '',
      // 模型偶尔漏写 actionSpec 或动作不合规，保留该行而不是卡死整表。
      actionSpec: normalizeAgentBV2ActionSpec(row.actionSpec),
    }]
  })
}

export function validateAgentBV2Rows(rows, options = {}) {
  const normalizedRows = normalizeAgentBV2BoardCells(rows)
  if (!normalizedRows.length) {
    return { ok: false, error: 'Agent B 必须返回至少一行五字段数据' }
  }
  return { ok: true, value: normalizedRows }
}

export function parseAgentBV2Response(text, options = {}) {
  const parsed = parseJsonObject(text)
  if (!isRecord(parsed)) return { ok: false, error: 'Agent B 返回内容不是 JSON 对象' }
  if (!Array.isArray(parsed.rows)) return { ok: false, error: 'Agent B 返回内容没有可用的 rows 数组' }
  return validateAgentBV2Rows(parsed.rows, options)
}
