<script setup>
/* @qh-core LANE=B-V2 POINT=UI_WORKBENCH five-field table primary */
import { computed, reactive, ref } from 'vue'
import { message } from 'ant-design-vue'
import {
  CheckCircleOutlined,
  DownloadOutlined,
  SettingOutlined,
  ThunderboltOutlined,
  ToolOutlined,
  PlusOutlined,
  DeleteOutlined,
} from '@ant-design/icons-vue'
import QhPageHeader from '../components/QhPageHeader.vue'
import { getAgentBoardToolCatalog } from '../board-tools/boardToolCatalog.js'
import {
  HANDWRITING_FONTS,
  ensureHandwritingFont,
  loadBoardTypographyConfig,
  saveBoardTypographyConfig,
} from '../board-tools/boardTypography.js'
import { generateAgentBV2Rows } from './service.js'
import { applyAgentBV2Timeline } from './timing.js'
import { checkAgentRows } from '../check-agent/service.js'
import { agentBApiConfig } from '../lib/agentBApiConfig.js'
import { exportSpeechMarkdown } from '../lib/speechMarkdown.js'

const props = defineProps({
  handoff: { type: Object, required: true },
})
const emit = defineEmits(['back-to-step1'])
const handoff = computed(() => props.handoff)
const typography = reactive(loadBoardTypographyConfig())
const rows = ref([])
const state = ref('idle')
const errorText = ref('')
const generatedModel = ref('')
const checkState = ref('idle')
const checkChanges = ref([])
const pendingCheckRows = ref(null)
const checkResultOpen = ref(false)
const settingsOpen = ref(false)
const toolsOpen = ref(false)
let checkRunId = 0
const toolCatalog = getAgentBoardToolCatalog()
const checkFieldLabels = {
  duration: '时间',
  stage: '环节',
  speech: '口播稿',
  board: '板书内容',
  actionSpec: '板书动作',
}

const registeredToolIds = new Set(toolCatalog.tools.map((tool) => tool.id))
const toolReferenceRows = [
  {
    key: 'underline',
    tool: 'rough-notation',
    action: 'underline',
    label: '下划线',
    usage: '在已有原文下画线；原文必须逐字一致',
  },
  {
    key: 'highlight',
    tool: 'rough-notation',
    action: 'highlight',
    label: '高亮',
    usage: '高亮已有原文；原文必须逐字一致',
  },
  {
    key: 'rough-line',
    tool: 'rough-line',
    label: '辅助线',
    usage: '分析/解题区画线；设计像素坐标',
  },
  {
    key: 'rough-arrow',
    tool: 'rough-arrow',
    label: '箭头',
    usage: '分析/解题区箭头；设计像素坐标',
  },
  {
    key: 'rough-rect',
    tool: 'rough-rect',
    label: '矩形',
    usage: '分析/解题区矩形框',
  },
  {
    key: 'rough-ellipse',
    tool: 'rough-ellipse',
    label: '椭圆',
    usage: '分析/解题区圆或椭圆',
  },
  {
    key: 'rough-polygon',
    tool: 'rough-polygon',
    label: '多边形',
    usage: '分析/解题区多边形',
  },
].filter((item) => registeredToolIds.has(item.tool))

const stageAccentColors = {
  '题目': '#1677ff',
  '分析': '#fa8c16',
  '解答': '#52c41a',
  '总结': '#722ed1',
}

const columns = [
  { title: '时间', key: 'duration', width: 90, fixed: 'left' },
  { title: '环节', key: 'stage', width: 80, fixed: 'left' },
  { title: '语音口播稿', key: 'speech', width: 300 },
  { title: '板书内容', key: 'board', width: 350 },
  { title: '板书动作', key: 'actionSpec', width: 110 },
  { title: '操作', key: 'operations', width: 100, fixed: 'right' },
]

const tableRows = computed(() => rows.value.map((row, index) => ({ ...row, _rowKey: `v2-${index}` })))
const problemTypeLabel = computed(() => ({
  geometry: '几何题',
  calculation: '计算题',
  word: '应用题',
}[handoff.value?.problemType] || handoff.value?.problemType || '未确认'))
const pureTextLabel = computed(() => (handoff.value?.imageKind || 'text_only') === 'text_only' ? '是' : '否')
const boardFocusLabel = computed(() => ({
  geometry_diagram: '几何图解',
  calculation_process: '演算过程',
  relation_understanding: '关系理解',
  mixed: '综合分析',
}[handoff.value?.boardFocus] || handoff.value?.boardFocus || '未确认'))
const relatedKnowledge = computed(() => Array.isArray(handoff.value?.relatedKnowledge)
  ? handoff.value.relatedKnowledge
  : [])
const knowledgeAnalysis = computed(() => handoff.value?.knowledgeAnalysis || null)
const coreKnowledge = computed(() => Array.isArray(knowledgeAnalysis.value?.coreKnowledge)
  ? knowledgeAnalysis.value.coreKnowledge
  : [])
const selectedKnowledge = ref(null)
const keyFormulaList = computed(() => Array.isArray(knowledgeAnalysis.value?.keyFormulaList)
  ? knowledgeAnalysis.value.keyFormulaList
  : [])
const uncertainItems = computed(() => Array.isArray(handoff.value?.uncertainItems)
  ? handoff.value.uncertainItems
  : [])
const suggestedLayoutLabel = computed(() => ({
  left_right: '左右布局',
  top_bottom: '上下布局',
}[handoff.value?.suggestedLayout?.layout] || handoff.value?.suggestedLayout?.layout || '无'))
const confirmedAtLabel = computed(() => formatDisplayTime(handoff.value?.confirmedAt))
const zoneParameterRows = computed(() => {
  const anchors = handoff.value?.zoneAnchors || {}
  const labels = { topic: '题目区', analysis: '分析区', solution: '解答区', summary: '总结区' }
  return Object.entries(labels).map(([key, label]) => ({
    key,
    label,
    value: formatRegion(anchors[key]?.regionStartCoord),
  }))
})
const handoffFlowSteps = computed(() => [
  { title: '识别题目', status: 'finish', description: '第1步已确认' },
  { title: '判断题型', status: handoff.value?.problemType ? 'finish' : 'wait', description: problemTypeLabel.value },
  { title: '画布排版', status: handoff.value?.boardPlan ? 'finish' : 'wait', description: '真画布与四区布局' },
  {
    title: '知识关联',
    status: relatedKnowledge.value.length ? 'finish' : 'wait',
    description: relatedKnowledge.value.length ? `${relatedKnowledge.value.length} 条可选参考` : '可选，按题目判断',
  },
  { title: '组装输入', status: 'finish', description: '题目、图片、布局、工具' },
  {
    title: '待发送生成',
    status: state.value === 'generating' ? 'process' : rows.value.length ? 'finish' : 'wait',
    description: state.value === 'generating'
      ? '正在生成 Agent B 五字段'
      : rows.value.length
        ? `已生成 ${rows.value.length} 行`
        : '准备就绪 · 点击生成',
  },
])

function formatDisplayTime(value) {
  const date = value ? new Date(value) : new Date()
  return Number.isNaN(date.valueOf()) ? String(value || '') : date.toLocaleString('zh-CN', { hour12: false })
}

function displayValue(value) {
  return typeof value === 'string' ? value : JSON.stringify(value)
}

function formatRegion(region) {
  if (!region) return '未规划'
  const pct = (value) => Number(Number(value).toFixed(2))
  const size = region.w == null ? '' : `，宽 ${pct(region.w)}%${region.h == null ? '' : `，高 ${pct(region.h)}%`}`
  return `起点 (${pct(region.x)}%, ${pct(region.y)}%)${size}`
}

async function persistTypographyConfig() {
  saveBoardTypographyConfig(typography)
}

function invalidateCheck() {
  checkRunId += 1
  checkState.value = 'idle'
  pendingCheckRows.value = null
}

function updateRow(index, field, value) {
  invalidateCheck()
  rows.value[index] = { ...rows.value[index], [field]: value }
  if (field === 'speech' || field === 'stage') rows.value = applyAgentBV2Timeline(rows.value)
}

function insertRowAfter(index) {
  invalidateCheck()
  const newRow = {
    duration: '待程序预估',
    stage: rows.value[index]?.stage || '分析',
    speech: '',
    board: '',
    actionSpec: [],
  }
  rows.value.splice(index + 1, 0, newRow)
  rows.value = applyAgentBV2Timeline(rows.value)
  message.success('已在下方插入空白行，快来写下补充内容吧 ╰(๑◕ ▿ ◕๑)╯')
}

function deleteRow(index) {
  if (rows.value.length <= 1) {
    message.warning('不能全部删完哦，最少要保留一行内容哈 ฅ(⌯꒦ິ³꒦ິ⌯)ฅ')
    return
  }
  invalidateCheck()
  rows.value.splice(index, 1)
  rows.value = applyAgentBV2Timeline(rows.value)
  message.success('已成功删除该行 ٩(｡•ω•｡)و')
}

function actionLabel(entry) {
  const action = entry?.action
  if (!action) return '能力缺口'
  return [action.tool, action.action].filter(Boolean).join(' · ')
}

function actionContent(entry) {
  if (entry?.capabilityGap) return entry.capabilityGap.need
  const action = entry?.action || {}
  return action.content || action.target?.exactText || entry?.cueText || ''
}

async function generateRows() {
  if (state.value === 'generating') return
  invalidateCheck()
  state.value = 'generating'
  errorText.value = ''
  try {
    Object.assign(typography, saveBoardTypographyConfig(typography))
    await ensureHandwritingFont(typography.fontId)
    const result = await generateAgentBV2Rows({
      handoff: handoff.value,
    })
    rows.value = result.rows
    generatedModel.value = result.model
    state.value = 'ready'
    message.success(`已生成 ${rows.value.length} 行五字段执行表`)
  } catch (error) {
    state.value = 'error'
    errorText.value = error?.message || String(error)
    message.error(errorText.value)
  }
}

async function checkRows() {
  if (!rows.value.length || checkState.value === 'checking') return
  const runId = ++checkRunId
  checkState.value = 'checking'
  errorText.value = ''
  checkChanges.value = []
  try {
    const result = await checkAgentRows({
      rows: rows.value,
    })
    if (runId !== checkRunId) return
    pendingCheckRows.value = result.rows
    checkChanges.value = result.changes
    checkState.value = 'ready'
    checkResultOpen.value = true
    message.success(result.changes.length ? `Check 完成，发现 ${result.changes.length} 处建议` : 'Check 完成，未发现需要修正的内容')
  } catch (error) {
    if (runId !== checkRunId) return
    checkState.value = 'error'
    errorText.value = error?.message || String(error)
    message.error(errorText.value)
  }
}

function applyCheckChanges() {
  if (!pendingCheckRows.value || !checkChanges.value.length) return
  rows.value = pendingCheckRows.value
  pendingCheckRows.value = null
  checkResultOpen.value = false
  message.success(`已应用 ${checkChanges.value.length} 处 Check 修改`)
}

function discardCheckChanges() {
  pendingCheckRows.value = null
  checkResultOpen.value = false
}

function exportSpeech() {
  if (!rows.value.length) return
  exportSpeechMarkdown(rows.value, {
    problemText: handoff.value?.problemText || '',
    model: generatedModel.value || agentBApiConfig.model || '',
    generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
  })
  message.success('口播稿 MD 已导出')
}

</script>

<template>
  <a-layout class="qh-page">
    <QhPageHeader
      step-label="第 2 步 · Agent B"
      subtitle="题目信息 → 五字段"
      show-back
      @back="emit('back-to-step1')"
    >
      <template #actions>
        <a-button title="可用工具" @click="toolsOpen = !toolsOpen">
          <template #icon><ToolOutlined /></template>
          工具
        </a-button>
        <a-button title="板书设置" @click="settingsOpen = !settingsOpen">
          <template #icon><SettingOutlined /></template>
          板书设置
        </a-button>
      </template>
    </QhPageHeader>

    <a-layout-content class="qh-page-content">
      <a-space direction="vertical" size="middle" style="width:100%">
        <a-card title="Agent B 输入交接台" class="qh-surface-card" size="small">
          <a-typography-text type="secondary">Agent A 交接摘要</a-typography-text>
          <a-steps
            class="qh-handoff-steps"
            size="small"
            :items="handoffFlowSteps"
          />
          <a-space wrap size="small" style="margin: 4px 0">
            <a-tag>题目 1 道</a-tag>
            <a-tag>画布分区 {{ handoff?.boardPlan ? 4 : 0 }} 个</a-tag>
            <a-tag>知识参考 {{ relatedKnowledge.length }} 条</a-tag>
            <a-tag>工具能力 {{ toolCatalog.tools.length }} 项</a-tag>
          </a-space>
          <a-descriptions bordered size="small" :column="2">
            <a-descriptions-item label="题目类型">{{ problemTypeLabel }}</a-descriptions-item>
            <a-descriptions-item label="是否纯文本">{{ pureTextLabel }}</a-descriptions-item>
            <a-descriptions-item label="板书侧重">{{ boardFocusLabel }}</a-descriptions-item>
            <a-descriptions-item label="交接时间">{{ confirmedAtLabel }}</a-descriptions-item>
            <a-descriptions-item label="四区布局">{{ handoff?.boardPlan ? '已确认' : '未确认' }}</a-descriptions-item>
            <a-descriptions-item label="四区参数" :span="2">
              <a-space wrap size="small">
                <a-tag v-for="zone in zoneParameterRows" :key="zone.key">
                  {{ zone.label }}：{{ zone.value }}
                </a-tag>
              </a-space>
            </a-descriptions-item>
            <a-descriptions-item label="建议年级">{{ handoff?.suggestedGrade || '未判断' }}</a-descriptions-item>
            <a-descriptions-item label="建议布局">{{ suggestedLayoutLabel }}</a-descriptions-item>
            <a-descriptions-item label="交接来源">
              {{ handoff?.agentPageName || 'Agent A' }} · {{ handoff?.agentCapability || '未声明能力' }} · v{{ handoff?.handoffVersion || 1 }}
            </a-descriptions-item>
            <a-descriptions-item label="知识分析">
              {{ coreKnowledge.length }} 个核心知识点 · {{ keyFormulaList.length }} 条公式
            </a-descriptions-item>
            <a-descriptions-item label="知识关联点" :span="2">
              <a-space v-if="relatedKnowledge.length" wrap size="small">
                <a-tag v-for="item in relatedKnowledge" :key="item['编号'] || item['知识点']" color="blue">
                  {{ item['知识点'] || '未命名知识点' }}
                </a-tag>
              </a-space>
              <a-typography-text v-else type="secondary">未查询，按 Agent A 结构化题文继续</a-typography-text>
            </a-descriptions-item>
            <a-descriptions-item v-if="knowledgeAnalysis?.teachingFocus" label="教学重点" :span="2">
              {{ knowledgeAnalysis.teachingFocus }}
            </a-descriptions-item>
            <a-descriptions-item v-if="keyFormulaList.length" label="关键公式" :span="2">
              <a-space wrap size="small">
                <a-tag v-for="formula in keyFormulaList" :key="formula" color="purple">{{ formula }}</a-tag>
              </a-space>
            </a-descriptions-item>
            <a-descriptions-item v-if="uncertainItems.length" label="待确认项" :span="2">
              <a-space wrap size="small">
                <a-tag v-for="item in uncertainItems" :key="displayValue(item)" color="orange">{{ displayValue(item) }}</a-tag>
              </a-space>
            </a-descriptions-item>
            <a-descriptions-item label="使用方式" :span="2">
              <a-typography-text type="secondary">
                Agent A 只给软建议，不是门槛或强制清单；锚定题目与四区骨架后，由 Agent B 自主取舍、改写和补充。
              </a-typography-text>
            </a-descriptions-item>
            <a-descriptions-item label="运行时补充">
              <a-typography-text type="secondary">当前时间与 Agent A 交接的布局随本次请求注入</a-typography-text>
            </a-descriptions-item>
            <a-descriptions-item label="课堂话术">
              <a-typography-text type="secondary">小学单题耐心讲解参考，按题目自然改写</a-typography-text>
            </a-descriptions-item>
          </a-descriptions>
          <div v-if="coreKnowledge.length" class="knowledge-chips">
            <a-tag
              v-for="item in coreKnowledge"
              :key="item.knowledgeId || item.knowledgePoint"
              color="blue"
              class="knowledge-chip"
              @click="selectedKnowledge = item"
            >
              {{ item.knowledgePoint || '未命名知识点' }}
            </a-tag>
          </div>
        </a-card>

        <a-alert
          v-if="errorText"
          type="error"
          show-icon
          :message="errorText"
        />


        <a-row :gutter="[16, 16]">
          <a-col :span="24">
            <a-card title="已确认题目" class="qh-surface-card">
              <template #extra>
                <a-tag color="blue">{{ problemTypeLabel }}</a-tag>
              </template>
              <a-typography-paragraph>{{ handoff?.problemText }}</a-typography-paragraph>
            </a-card>
          </a-col>
        </a-row>

        <a-card class="qh-surface-card">
          <template #title>
            <a-space>
              <span>五字段执行表</span>
              <a-tag color="blue">{{ problemTypeLabel }}</a-tag>
              <a-tag v-if="generatedModel" color="green">{{ generatedModel }}</a-tag>
              <a-tag v-if="rows.length">{{ rows.length }} 行</a-tag>
            </a-space>
          </template>
          <template #extra>
            <a-space size="middle" wrap>
              <a-typography-text type="secondary">主工作区 · 170字/分估时</a-typography-text>
              <a-button
                :disabled="!rows.length || state === 'generating'"
                :loading="checkState === 'checking'"
                title="手动调用独立 Check Agent，润色当前表格内容"
                @click="checkRows"
              >
                <template #icon><CheckCircleOutlined /></template>
                Check Agent
              </a-button>
              <a-button
                :disabled="!rows.length"
                title="将当前口播稿保存为 Markdown 文件"
                @click="exportSpeech"
              >
                <template #icon><DownloadOutlined /></template>
                一键导出口播稿 MD
              </a-button>
              <a-button
                type="primary"
                :loading="state === 'generating'"
                @click="generateRows"
              >
                <template #icon><ThunderboltOutlined /></template>
                生成 Agent B 五字段
              </a-button>
            </a-space>
          </template>

          <div v-if="!rows.length" style="padding: 20px 0; display:flex; align-items:center; gap:11px;">
            <a-typography-text type="secondary">题目信息已就绪，点击右上角"生成"按钮</a-typography-text>
          </div>
          <a-table
            v-else
            :columns="columns"
            :data-source="tableRows"
            row-key="_rowKey"
            :pagination="false"
            :scroll="{ x: 1060 }"
            size="small"
            bordered
          >
            <template #bodyCell="{ column, record, index }">
              <a-typography-text
                v-if="column.key === 'duration'"
                type="secondary"
                style="font-size: 10px; display: block; line-height: 1.5; white-space: pre-wrap"
              >{{ record.duration }}</a-typography-text>
              <div
                v-else-if="column.key === 'stage'"
                :style="{ borderLeft: `3px solid ${stageAccentColors[record.stage] || '#d9d9d9'}`, paddingLeft: '6px' }"
              >
                <a-select
                  :value="record.stage"
                  size="small"
                  style="width: 100%"
                  @change="(value) => updateRow(index, 'stage', value)"
                >
                  <a-select-option v-for="stage in ['题目', '分析', '解答', '总结']" :key="stage" :value="stage">
                    {{ stage }}
                  </a-select-option>
                </a-select>
              </div>
              <a-popover
                v-else-if="column.key === 'actionSpec' && record.actionSpec.length"
                trigger="click"
                placement="left"
              >
                <template #content>
                  <a-list
                    :data-source="record.actionSpec"
                    size="small"
                    style="width: 360px; max-height: 420px; overflow: auto"
                  >
                    <template #renderItem="{ item }">
                      <a-list-item>
                        <a-space direction="vertical" size="small">
                          <a-space :size="4" wrap>
                            <a-tag v-if="item.action?.order" color="blue">#{{ item.action.order }}</a-tag>
                            <a-tag>{{ actionLabel(item) }}</a-tag>
                          </a-space>
                          <a-typography-text>{{ actionContent(item) }}</a-typography-text>
                        </a-space>
                      </a-list-item>
                    </template>
                  </a-list>
                </template>
                <a-tag color="processing" style="cursor: pointer">{{ record.actionSpec.length }} 个动作</a-tag>
              </a-popover>
              <span v-else-if="column.key === 'actionSpec'" style="color: #bfbfbf; font-size: 11px">—</span>
              <div v-else-if="column.key === 'operations'">
                <a-space size="small">
                  <a-button
                    type="primary"
                    shape="circle"
                    size="small"
                    title="在下方新增一行"
                    @click="insertRowAfter(index)"
                  >
                    <template #icon><PlusOutlined /></template>
                  </a-button>
                  <a-popconfirm
                    title="确定要删除这一行吗？"
                    ok-text="确定"
                    cancel-text="取消"
                    @confirm="deleteRow(index)"
                  >
                    <a-button
                      type="primary"
                      danger
                      shape="circle"
                      size="small"
                      title="删除这一行"
                    >
                      <template #icon><DeleteOutlined /></template>
                    </a-button>
                  </a-popconfirm>
                </a-space>
              </div>
              <a-textarea
                v-else
                :value="record[column.key]"
                :auto-size="{ minRows: 2, maxRows: 8 }"
                style="font-size: 12px"
                @change="(event) => updateRow(index, column.key, event.target.value)"
              />
            </template>
          </a-table>
        </a-card>

        <a-card v-if="toolsOpen" title="可用工具（人话）" class="qh-surface-card" size="small">
          <template #extra>
            <a-typography-text type="secondary">单手串行 · 随口播触发</a-typography-text>
          </template>
          <a-list
            :grid="{ gutter: 8, column: 4 }"
            :data-source="toolReferenceRows"
            size="small"
          >
            <template #renderItem="{ item }">
              <a-list-item>
                <a-list-item-meta :title="item.label" :description="item.usage" />
              </a-list-item>
            </template>
          </a-list>
        </a-card>
      </a-space>
    </a-layout-content>
    <a-modal
      :open="Boolean(selectedKnowledge)"
      :title="selectedKnowledge?.knowledgePoint || '知识点详情'"
      width="720px"
      :footer="null"
      @cancel="selectedKnowledge = null"
    >
      <a-descriptions v-if="selectedKnowledge" bordered size="small" :column="1" class="knowledge-detail-table">
        <a-descriptions-item label="编号">{{ selectedKnowledge.knowledgeId || '未提供' }}</a-descriptions-item>
        <a-descriptions-item label="学段 / 系列 / 类型">
          {{ [selectedKnowledge.rawKnowledgeRecord?.学段, selectedKnowledge.rawKnowledgeRecord?.系列, selectedKnowledge.rawKnowledgeRecord?.类型].filter(Boolean).join(' / ') || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="经典样题">{{ selectedKnowledge.rawKnowledgeRecord?.经典样题 || '未提供' }}</a-descriptions-item>
        <a-descriptions-item label="考点">{{ selectedKnowledge.examinationPoint || selectedKnowledge.rawKnowledgeRecord?.考点 || '未提供' }}</a-descriptions-item>
        <a-descriptions-item label="策略方法">{{ selectedKnowledge.strategy || selectedKnowledge.rawKnowledgeRecord?.策略方法 || '未提供' }}</a-descriptions-item>
        <a-descriptions-item label="讲解要点">{{ selectedKnowledge.rawKnowledgeRecord?.讲解要点举例 || '未提供' }}</a-descriptions-item>
        <a-descriptions-item label="易错点">{{ selectedKnowledge.commonMistakes?.join('；') || selectedKnowledge.rawKnowledgeRecord?.易错点 || '未提供' }}</a-descriptions-item>
        <a-descriptions-item label="公式">{{ selectedKnowledge.formula || '按本题判断' }}</a-descriptions-item>
        <a-descriptions-item label="总结归纳">{{ selectedKnowledge.summary || selectedKnowledge.rawKnowledgeRecord?.总结归纳 || '未提供' }}</a-descriptions-item>
      </a-descriptions>
    </a-modal>
    <a-modal
      v-model:open="checkResultOpen"
      title="Check Agent 润色结果"
      :width="760"
      @cancel="discardCheckChanges"
    >
      <div v-if="!checkChanges.length" class="qh-check-empty">
        <CheckCircleOutlined />
        <div>
          <strong>未发现需要润色的内容</strong>
          <p>当前五字段执行表保持原样。</p>
        </div>
      </div>
      <a-list v-else bordered :data-source="checkChanges" class="qh-check-list">
        <template #renderItem="{ item }">
          <a-list-item>
            <div class="qh-check-change">
              <a-space wrap size="small">
                <a-tag color="blue">第 {{ item.row || '?' }} 行</a-tag>
                <a-tag>{{ checkFieldLabels[item.field] || item.field }}</a-tag>
                <a-typography-text type="secondary">{{ item.reason }}</a-typography-text>
              </a-space>
              <div class="qh-check-diff">
                <div>
                  <span>原文</span>
                  <p>{{ item.before || '（空）' }}</p>
                </div>
                <div>
                  <span>修正后</span>
                  <p>{{ item.after || '（空）' }}</p>
                </div>
              </div>
            </div>
          </a-list-item>
        </template>
      </a-list>
      <template #footer>
        <a-button @click="discardCheckChanges">保留原文</a-button>
        <a-button v-if="checkChanges.length" type="primary" @click="applyCheckChanges">
          应用 {{ checkChanges.length }} 处修改
        </a-button>
      </template>
    </a-modal>
    <a-drawer
      v-model:open="settingsOpen"
      title="板书设置"
      :width="360"
      placement="right"
    >
      <a-form layout="vertical">
        <a-form-item label="板书字体">
          <a-select v-model:value="typography.fontId" aria-label="板书字体" @change="persistTypographyConfig">
            <a-select-option v-for="font in HANDWRITING_FONTS" :key="font.id" :value="font.id">
              {{ font.label }}
            </a-select-option>
          </a-select>
        </a-form-item>
      </a-form>
    </a-drawer>
  </a-layout>
</template>

<style scoped>
.knowledge-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 11px;
}

.knowledge-chip {
  margin: 0;
  padding: 3px 11px;
  border-radius: 999px;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}

.knowledge-chip:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.16);
}

.knowledge-detail-table :deep(.ant-descriptions-item-label) {
  width: 132px;
  color: #49627c;
  background: #f6faff;
}

.qh-check-empty {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 22px 4px;
  color: #1677ff;
  font-size: 22px;
}

.qh-check-empty p {
  margin: 4px 0 0;
  color: #666;
  font-size: 12px;
}

.qh-check-change {
  width: 100%;
}

.qh-check-diff {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 10px;
  margin-top: 10px;
}

.qh-check-diff > div {
  min-width: 0;
  padding: 10px 12px;
  border: 1px solid #e8e8e8;
  border-radius: 6px;
  background: #fafafa;
}

.qh-check-diff > div:last-child {
  border-color: #b7ebc6;
  background: #f6ffed;
}

.qh-check-diff span {
  color: #8c8c8c;
  font-size: 11px;
}

.qh-check-diff p {
  margin: 5px 0 0;
  color: #262626;
  font-size: 12px;
  line-height: 1.6;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

@media (max-width: 720px) {
  .qh-check-diff {
    grid-template-columns: 1fr;
  }
}
</style>
