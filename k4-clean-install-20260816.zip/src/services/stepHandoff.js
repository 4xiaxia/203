/* @qh-core LANE=STEP1 POINT=HANDOFF_OWNER payload from Agent A to Agent B */
/**
 * 第1步 → 板书参数书稿页 交接
 * 信号：用户点击「确定进入生成表」
 * 核心：题目内容、题型、板书侧重 + 第1步已定题目坐标
 */
import { CANVAS_W, CANVAS_H } from '../utils/canvasCoords.js'

export function hasUsableAgentAKnowledge(analysis) {
  return Array.isArray(analysis?.coreKnowledge) && analysis.coreKnowledge.length > 0
}

export function buildStep1Handoff(input = {}) {
  const problemText = String(input.problemText || '').trim()
  const problemType = input.problemType || null
  const boardFocus = input.boardFocus || null
  const imageKind = input.imageKind || (input.keepOriginal ? 'has_diagram' : 'text_only')
  const topicLayout = roundLayoutNumbers(input.topicLayout || null)
  const relatedKnowledge = Array.isArray(input.relatedKnowledge)
    ? JSON.parse(JSON.stringify(input.relatedKnowledge))
    : null
  const previewDataUrl = String(input.previewDataUrl || '')

  // Agent A 深度知识点分析结果（识别时 LLM 直接产出）
  const knowledgeAnalysis = hasUsableAgentAKnowledge(input.knowledgeAnalysis)
    ? JSON.parse(JSON.stringify(input.knowledgeAnalysis))
    : null

  // 从 knowledgeAnalysis 提取参考年级（供 Agent B 参考）
  const suggestedGrade = String(input.suggestedGrade || knowledgeAnalysis?.suggestedGrade || '').trim()

  // 坐标规范声明（Agent B 在生成 draw 动作时必须遵循此格式）
  const coordinateSpec = {
    canvasSize: { w: CANVAS_W, h: CANVAS_H, unit: 'px' },
    coordinateSystem: '百分比坐标 (0-100)，原点左上',
    format: {
      point: '起点：(x%, y%)',
      endpoint: '终点：(x%, y%)',
      region: '区域：[左%, 上%, 宽%, 高%]，所有百分比最多保留 2 位小数',
    },
    conversionFormula: {
      xPx: 'xPx = xPercent / 100 × 1726',
      yPx: 'yPx = yPercent / 100 × 980',
    },
    example: '若分析区起手坐标为 (6%, 41%)，则对应像素 (103.56, 401.8)，约 (104, 402)',
  }

  // 从 boardPlan 提取各区域起手坐标（落座标签 + 区域起点）
  const boardPlan = roundLayoutNumbers(input.boardPlan || null)
  const zoneAnchors = extractZoneAnchors(boardPlan, topicLayout)

  return {
    handoffVersion: 1,
    confirmedAt: new Date().toISOString(),
    problemText,
    problemType,
    boardFocus,
    relatedKnowledge,
    knowledgeAnalysis,
    suggestedGrade,
    uncertainItems: Array.isArray(input.uncertainItems) ? [...input.uncertainItems] : [],
    suggestedLayout: input.suggestedLayout || null,
    imageKind,
    keepOriginal: Boolean(input.keepOriginal),
    sourceImageDataUrl: input.sourceImageDataUrl || '',
    canvas: { w: CANVAS_W, h: CANVAS_H, unit: 'px' },
    coordinateSpec,
    zoneAnchors,
    topicLayout,
    boardPlan,
    showGrid: Boolean(input.showGrid),
    previewDataUrl,
    agentPageName: input.agentPageName || '',
    agentCapability: input.agentCapability || '',
  }
}

function roundLayoutNumbers(value) {
  if (Array.isArray(value)) return value.map(roundLayoutNumbers)
  if (value && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, roundLayoutNumbers(item)]))
  }
  return typeof value === 'number' && Number.isFinite(value)
    ? Number(value.toFixed(2))
    : value
}

/**
 * 从 boardPlan + topicLayout 提取各区域的标签位置和起手坐标。
 * 这些坐标会传给 Agent B，让它在生成 draw 动作时有明确的落点参考。
 */
function extractZoneAnchors(boardPlan, topicLayout) {
  if (!boardPlan) return null
  const anchors = {}
  // 题目区
  if (topicLayout?.topicLabel) {
    anchors.topic = {
      label: topicLayout.topicLabel,
      labelStartCoord: { x: topicLayout.topicLabel.x, y: topicLayout.topicLabel.y },
      regionStartCoord: topicLayout.question
        ? { x: topicLayout.question.x, y: topicLayout.question.y }
        : null,
    }
  }
  // 分析区、解答区、总结区
  const zones = ['analysis', 'solution', 'summary']
  const labelZones = ['analysisLabel', 'solutionLabel', 'summaryLabel']
  for (let i = 0; i < zones.length; i += 1) {
    const zone = zones[i]
    const labelKey = labelZones[i]
    const label = boardPlan[labelKey]
    const region = boardPlan[zone]
    if (label || region) {
      anchors[zone] = {
        label: label || null,
        labelStartCoord: label
          ? { x: label.x, y: label.y }
          : null,
        regionStartCoord: region
          ? { x: region.x, y: region.y, w: region.w, h: region.h || null }
          : null,
      }
    }
  }
  return anchors
}
