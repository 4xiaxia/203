import { applyAgentBV2Timeline } from '../agent-b-v2/timing.js'
import { getCheckAgentApiSnapshot } from '../lib/checkAgentApiConfig.js'

export async function checkAgentRows({ rows }) {
  if (!Array.isArray(rows) || !rows.length) throw new Error('没有可检查的 Agent B 生成内容')

  const userSnap = getCheckAgentApiSnapshot()
  if (!userSnap.apiKey || !userSnap.endpoint || !userSnap.model) {
    throw new Error('Check Agent API 配置不完整')
  }

  const controller = new AbortController()
  const timeoutId = window.setTimeout(() => controller.abort(), 185000)
  let response
  let data
  try {
    response = await fetch('/api/check-agent/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify({
        endpoint: userSnap.endpoint,
        model: userSnap.model,
        apiKey: userSnap.apiKey,
        currentRows: rows,
      }),
    })
    data = await response.json().catch(() => ({}))
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('Check Agent 连续两次请求均超时，已取消')
    throw error
  } finally {
    window.clearTimeout(timeoutId)
  }

  if (!response.ok || !data.ok) throw new Error(data.error || `Check Agent 失败 ${response.status}`)
  return {
    rows: applyAgentBV2Timeline(data.rows),
    changes: Array.isArray(data.changes) ? data.changes : [],
    model: data.model || userSnap.model,
    usage: data.usage || null,
  }
}
