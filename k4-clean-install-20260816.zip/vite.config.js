import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'
import { createRecognitionProxyPlugin } from './server/recognitionHandler.js'
import { agentBV2ProxyPlugin } from './server/agentBV2Handler.js'
import { checkAgentProxyPlugin } from './server/checkAgentHandler.js'
import { AGENT_A_KNOWLEDGE_BASE } from './server/docReferences.js'

export default defineConfig({
  plugins: [
    vue(),
    createRecognitionProxyPlugin({ knowledgeBase: AGENT_A_KNOWLEDGE_BASE }),
    agentBV2ProxyPlugin(),
    checkAgentProxyPlugin(),
  ],
  server: {
    host: true,
    port: 5173,
  },
})
