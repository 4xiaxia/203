/* Check Agent — 独立模块，只做 4 件事：
   1. 口播/板书字符转义 & ASR 发音校正
   2. 答案数学正确性校验（只报告，不自己改答案）
   3. 废话合并：重复啰嗦、没有实质前进的行合并/精简
   4. 语气衔接去课后答案腔

   数据来源：从 boardResultStore 读当前 B 生成结果（文件即真相源）
   修改方式：生成建议版本，写回独立文件，前端弹窗让用户确认后才应用
*/

import { CHECK_AGENT_SYSTEM_PROMPT } from '../src/check-agent/prompt.js'
import {
  readCurrentResult,
  overwriteCurrentResult,
  saveOriginalBackup,
  loadOriginalBackup,
  hasOriginalBackup,
} from './boardResultStore.js'
import {
  isOptions,
  readJsonBody,
  requestChatCompletion,
  resolveUserCredentials,
  sendJson,
  getChatMessageText,
} from './http.js'

// ---------- JSON 解析 ----------
function parseJsonObject(text) {
  const source = String(text || '').trim()
  const fenced = source.match(/```(?:json)?\s*([\s\S]*?)```/i)?.[1]?.trim()
  const candidate = fenced || source
  try { return JSON.parse(candidate) } catch { /* fall through */ }
  const start = candidate.indexOf('{')
  const end = candidate.lastIndexOf('}')
  if (start < 0 || end <= start) return null
  try { return JSON.parse(candidate.slice(start, end + 1)) } catch { return null }
}

// ---------- board / actionSpec 规范化（借用 B 的合同） ----------
import { normalizeBoard, normalizeAgentBV2ActionSpec } from '../src/agent-b-v2/contract.js'

function valuesMatch(left, right) {
  return JSON.stringify(left) === JSON.stringify(right)
}

function formatChangeValue(value) {
  return typeof value === 'string' ? value : JSON.stringify(value ?? '')
}

// ---------- 解析 Check Agent 返回 ----------
const ALLOWED_FIELDS = new Set(['speech', 'board', 'actionSpec', 'answer_error'])

function parseCheckResponse(text, originalRows) {
  const parsed = parseJsonObject(text)
  if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { ok: false, error: '返回内容不是 JSON 对象' }
  }
  if (!Array.isArray(parsed.rows) || !parsed.rows.length) {
    return { ok: false, error: '返回的 rows 为空' }
  }

  // 校验 stage 顺序不变（允许行数减少，但 stage 出现顺序必须和原始一致）
  const originalStageSeq = originalRows.map(r => r.stage)
  const newStageSeq = parsed.rows.map(r => r.stage)
  let origIdx = 0
  for (const stage of newStageSeq) {
    while (origIdx < originalStageSeq.length && originalStageSeq[origIdx] !== stage) {
      origIdx++
    }
    if (origIdx >= originalStageSeq.length) {
      return { ok: false, error: `stage 顺序被打乱或出现了未知 stage：${stage}` }
    }
    origIdx++
  }

  const rows = parsed.rows.map((row) => ({
    stage: row?.stage || '',
    speech: typeof row?.speech === 'string' ? row.speech : '',
    board: row?.board !== undefined && row?.board !== null
      ? normalizeBoard(row.board)
      : '',
    actionSpec: Array.isArray(row?.actionSpec)
      ? normalizeAgentBV2ActionSpec(row.actionSpec)
      : [],
  }))

  // 生成 changes 报告
  const reportedChanges = (Array.isArray(parsed.changes) ? parsed.changes : [])
    .map((c) => ({
      row: Number.isFinite(Number(c?.row)) ? Math.max(1, Math.round(Number(c.row))) : null,
      field: String(c?.field || '').trim(),
      before: c?.before !== undefined ? String(c.before) : '',
      after: c?.after !== undefined ? String(c.after) : '',
      reason: String(c?.reason || '').trim(),
    }))
    .filter((c) => ALLOWED_FIELDS.has(c.field) && c.reason)

  const changes = []

  // 1. 模型报告的 changes（speech / board / actionSpec / answer_error）
  //    优先用模型自己的描述，信息最准确
  for (const rc of reportedChanges) {
    changes.push(rc)
  }

  // 2. 兜底：逐行对比，补上模型改了但没报告的变化
  //    （模型可能漏写 changes 数组，但 rows 里已经改了内容）
  const reportedKeys = new Set(
    reportedChanges
      .filter(c => c.row !== null && c.field !== 'answer_error')
      .map(c => `${c.row}:${c.field}`)
  )
  const minLen = Math.min(originalRows.length, rows.length)
  for (let i = 0; i < minLen; i++) {
    const orig = originalRows[i]
    const chk = rows[i]
    for (const field of ['speech', 'board', 'actionSpec']) {
      const key = `${i + 1}:${field}`
      if (reportedKeys.has(key)) continue // 模型已经报告过了，跳过
      const origVal = orig?.[field]
      const chkVal = chk?.[field]
      if (!valuesMatch(origVal, chkVal)) {
        changes.push({
          row: i + 1,
          field,
          before: formatChangeValue(origVal),
          after: formatChangeValue(chkVal),
          reason: '内容优化（模型未标注原因）',
        })
      }
    }
  }

  // 3. 行数变化（合并/删除）
  if (rows.length !== originalRows.length) {
    changes.push({
      row: null,
      field: 'structure',
      before: `${originalRows.length} 行`,
      after: `${rows.length} 行`,
      reason: `合并/精简了 ${originalRows.length - rows.length} 行`,
    })
  }

  return { ok: true, value: { rows, changes } }
}

// ---------- HTTP handler ----------
export async function handleCheckAgentRequest(req, res) {
  if (isOptions(req, res)) return true
  if (req.method !== 'POST') return false

  try {
    const body = await readJsonBody(req)
    let credentials
    try {
      credentials = resolveUserCredentials(body)
    } catch (error) {
      return sendJson(req, res, 400, { ok: false, error: error.message })
    }

    // 优先用前端传来的 rows（用户可能手动改过），没有就从真相源读
    let originalRows
    if (Array.isArray(body.currentRows) && body.currentRows.length) {
      originalRows = body.currentRows
    } else {
      const current = readCurrentResult()
      originalRows = current?.result?.rows
    }
    if (!Array.isArray(originalRows) || !originalRows.length) {
      return sendJson(req, res, 400, {
        ok: false,
        error: '没有可检查的 Agent B 生成内容，请先生成',
      })
    }

    // 从 handoff 取 boardPlan 和 coordinateMode 做参照（只读不写）
    const handoff = readCurrentResult()?.result?.handoff
    const boardPlan = handoff?.boardPlan || null
    const coordinateMode = handoff?.canvasParams?.coordinateMode || 'percentage'

    const userContent = [
      {
        type: 'text',
        text: `【坐标输出模式】\n${coordinateMode}`,
      },
      {
        type: 'text',
        text: `【参考 boardPlan】\n${JSON.stringify(boardPlan, null, 2)}\n\n（仅用于判断坐标区域，不修改 stage 或步骤结构）`,
      },
      {
        type: 'text',
        text: `【当前 B 生成结果四字段】\n${JSON.stringify(originalRows, null, 2)}`,
      },
    ]

    const { response, data } = await requestChatCompletion({
      ...credentials,
      timeoutMs: 90000,
      body: {
        temperature: 0.3,
        stream: false,
        response_format: { type: 'json_object' },
        messages: [
          { role: 'system', content: CHECK_AGENT_SYSTEM_PROMPT },
          { role: 'user', content: userContent },
        ],
      },
    })

    if (!response.ok) {
      return sendJson(req, res, response.status, {
        ok: false,
        error: data?.error?.message || data?.message || `上游失败 ${response.status}`,
      })
    }

    const text = getChatMessageText(data?.choices?.[0]?.message)
    const parsed = parseCheckResponse(text, originalRows)

    if (!parsed.ok) {
      // Check 是可选润色，解析失败时回退原表，不阻塞
      return sendJson(req, res, 200, {
        ok: true,
        checkStatus: 'failed_fallback',
        checkError: parsed.error || '返回格式无法解析，已回退原表',
        model: credentials.model,
        rows: originalRows,
        changes: [],
        usage: data?.usage || null,
      })
    }

    // Check 结果只做建议，不直接覆写文件。前端弹窗让用户确认后，调用 apply 接口才写回。
    return sendJson(req, res, 200, {
      ok: true,
      model: credentials.model,
      rows: parsed.value.rows,
      changes: parsed.value.changes,
      usage: data?.usage || null,
    })
  } catch (error) {
    const status = error?.name === 'AbortError' ? 504 : 500
    return sendJson(req, res, status, {
      ok: false,
      error: error?.name === 'AbortError'
        ? '上游超时（90 秒）'
        : error?.message || String(error),
    })
  }
}

// 还原到 Check 之前的原始版本
export async function handleCheckRevertRequest(req, res) {
  if (isOptions(req, res)) return true
  if (req.method !== 'POST') return false

  try {
    const current = readCurrentResult()
    if (!current) {
      return sendJson(req, res, 400, { ok: false, error: '没有找到当前 B 生成结果' })
    }
    if (!hasOriginalBackup(current.filename)) {
      return sendJson(req, res, 400, { ok: false, error: '没有找到原始备份，无法还原' })
    }
    const original = loadOriginalBackup(current.filename)
    if (!original) {
      return sendJson(req, res, 500, { ok: false, error: '原始备份读取失败' })
    }
    const { filename } = overwriteCurrentResult(original)
    return sendJson(req, res, 200, {
      ok: true,
      filename,
      rows: original.rows || [],
      reverted: true,
    })
  } catch (error) {
    return sendJson(req, res, 500, {
      ok: false,
      error: error?.message || String(error),
    })
  }
}

// 应用 Check 结果：覆写当前 board-result 文件
export async function handleCheckApplyRequest(req, res) {
  if (isOptions(req, res)) return true
  if (req.method !== 'POST') return false

  try {
    const body = await readJsonBody(req)
    const rows = body.rows
    if (!Array.isArray(rows) || !rows.length) {
      return sendJson(req, res, 400, { ok: false, error: '缺少 rows 参数' })
    }

    const current = readCurrentResult()
    if (!current) {
      return sendJson(req, res, 400, { ok: false, error: '没有找到当前 B 生成结果' })
    }

    // 第一次 apply 前保存原始备份（只存一次，不覆盖）
    saveOriginalBackup(current.filename, current.result)

    // 覆写当前文件（保留原文件其他字段，只更新 rows 和 checkedAt）
    const updated = {
      ...current.result,
      rows,
      checkedAt: new Date().toISOString(),
    }
    const { filename } = overwriteCurrentResult(updated)

    return sendJson(req, res, 200, {
      ok: true,
      filename,
      rows,
    })
  } catch (error) {
    return sendJson(req, res, 500, {
      ok: false,
      error: error?.message || String(error),
    })
  }
}

// ---------- Vite 插件 ----------
export function checkAgentProxyPlugin() {
  return {
    name: 'check-agent-proxy',
    configureServer(server) {
      server.middlewares.use('/api/check-agent/check', (req, res, next) => {
        Promise.resolve(handleCheckAgentRequest(req, res)).then((handled) => {
          if (!handled) next()
        }).catch(next)
      })
      server.middlewares.use('/api/check-agent/apply', (req, res, next) => {
        Promise.resolve(handleCheckApplyRequest(req, res)).then((handled) => {
          if (!handled) next()
        }).catch(next)
      })
      server.middlewares.use('/api/check-agent/revert', (req, res, next) => {
        Promise.resolve(handleCheckRevertRequest(req, res)).then((handled) => {
          if (!handled) next()
        }).catch(next)
      })
    },
  }
}
