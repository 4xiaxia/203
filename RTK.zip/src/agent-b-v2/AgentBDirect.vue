<script setup>
/* @qh-core LANE=B-V2 POINT=UI_WORKBENCH five-field table primary */
import { computed, ref, toRaw, watch } from 'vue'
import { message } from 'ant-design-vue'
import katex from 'katex'
import 'katex/dist/katex.min.css'
import {
  CheckCircleOutlined,
  WarningOutlined,
  DownloadOutlined,
  SettingOutlined,
  ThunderboltOutlined,
  ToolOutlined,
  PlusOutlined,
  DeleteOutlined,
  RollbackOutlined,
} from '@ant-design/icons-vue'
import QhPageHeader from '../components/QhPageHeader.vue'
import { getAgentBoardToolCatalog } from '../board-tools/boardToolCatalog.js'
import { BOARD_MARK_COLORS } from '../board-tools/roughNotationTool.js'
import { ROUGH_DRAWING_COLORS } from '../board-tools/roughDrawingTool.js'
// B 是剧本编剧，不负责板书字体。甲方后续启用独立播放器时再恢复此配置。
// import {
//   HANDWRITING_FONTS,
//   ensureHandwritingFont,
//   loadBoardTypographyConfig,
//   saveBoardTypographyConfig,
// } from '../board-tools/boardTypography.js'
import { generateAgentBV2Rows } from './service.js'
import { applyAgentBV2Timeline } from './timing.js'
import { listSkills, DEFAULT_SKILL_ID } from './skills/index.js'
import { checkAgentRows, applyCheckResult, revertCheckResult } from '../check-agent/service.js'
import { agentBApiConfig } from '../lib/agentBApiConfig.js'
import { userApiConfig } from '../lib/userApiConfig.js'
import { exportElementsMarkdown, exportSpeechMarkdown, exportStoryboardMarkdown } from '../lib/speechMarkdown.js'

const props = defineProps({
  initialHandoff: { type: Object, required: true },
})
const emit = defineEmits(['back-to-step1'])
// props.initialHandoff 是 Vue readonly reactive，直接 JSON.stringify 会触发 ReactiveEffect 循环引用
// 必须先用 toRaw 取原始对象再深拷贝
const localHandoff = ref(JSON.parse(JSON.stringify(toRaw(props.initialHandoff))))
const handoff = computed(() => localHandoff.value)
// props 变化时同步更新 localHandoff（父组件重新传入 handoff 时）
watch(() => props.initialHandoff, (val) => {
  if (val) localHandoff.value = JSON.parse(JSON.stringify(toRaw(val)))
}, { deep: true })
// const typography = reactive(loadBoardTypographyConfig())
const rows = ref([])
const state = ref('idle')
const errorText = ref('')
const generatedModel = ref('')
const checkState = ref('idle')
const checkChanges = ref([])
const pendingCheckRows = ref(null)
const checkResultOpen = ref(false)
const checkFailedFallback = ref(false)
const toolsOpen = ref(false)
const customSystemPrompt = ref('')
const refineLoading = ref(false)
const refineResultOpen = ref(false)
const refineResult = ref(null)
const skillList = listSkills()
const selectedSkillId = ref(DEFAULT_SKILL_ID)
const promptEditOpen = ref(false)
const currentSkillName = computed(() => {
  if (customSystemPrompt.value?.trim()) return '自定义提示词'
  const skill = skillList.find(s => s.id === selectedSkillId.value)
  return skill?.name || selectedSkillId.value
})
let checkRunId = 0
const toolCatalog = getAgentBoardToolCatalog()
const checkFieldLabels = {
  stage: '环节',
  speech: '口播稿',
  board: '板书内容',
  actionSpec: '板书动作',
}

const toolLabels = {
  underline: '下划线',
  highlight: '高亮',
  'rough-line': '辅助线',
  'rough-arrow': '箭头',
}

function formatToolFields(schema) {
  return Object.entries(schema).map(([name, value]) => ({
    name,
    value: typeof value === 'string' ? value : JSON.stringify(value),
  }))
}

function formatToolExample(example) {
  return JSON.stringify({ action: example }, null, 2)
}

const toolReferenceRows = toolCatalog.tools.flatMap((tool) => {
  if (tool.actions) {
    return tool.actions.map((item) => ({
      key: item.action,
      tool: tool.id,
      label: toolLabels[item.action] || item.action,
      summary: item.description,
      fields: formatToolFields({ ...tool.actionSchema, action: item.action }),
      example: formatToolExample(item.example),
    }))
  }
  return [{
    key: tool.id,
    tool: tool.id,
    label: toolLabels[tool.id] || tool.id,
    summary: tool.purpose,
    fields: formatToolFields(tool.actionSchema),
    example: formatToolExample(tool.example),
  }]
})

const stageAccentColors = {
  '题目': '#1677ff',
  '分析': '#fa8c16',
  '解答': '#52c41a',
  '总结': '#722ed1',
}

// stage 标签颜色（antd 内置色名，自动生成浅底色+深文字）
const stageTagColors = {
  '题目': 'blue',
  '分析': 'orange',
  '解答': 'green',
  '总结': 'purple',
}

// 画布参数配置（导出时跟着要素表一起导出）
const canvasParams = ref({
  coordinateMode: 'percentage',
  questionFontSize: 30,
  questionFontFamily: '"Segoe UI", "PingFang SC", "Microsoft YaHei", sans-serif',
  questionLineHeight: 1.65,
  rowGapMs: 1500,
  speechSpeed: 160,
})

// board 列编辑状态：-1 表示无编辑，>=0 表示正在编辑的行索引
const editingBoardIndex = ref(-1)

// 解析 board 字段，兼容 v1.0(string) 和 v2.0(object {startCoord, content})
function parseBoard(board) {
  if (board == null) return { startCoord: '', content: '' }
  if (typeof board === 'string') {
    // v1.0 兼容：尝试解析 [x%, y%] 前缀
    const match = board.match(/^\[(\d+(?:\.\d+)?%\s*,\s*\d+(?:\.\d+)?%)\]\s*/)
    if (match) return { startCoord: '[' + match[1] + ']', content: board.slice(match[0].length) }
    return { startCoord: '', content: board }
  }
  if (typeof board === 'object') {
    return {
      startCoord: board.startCoord || '',
      content: board.content || '',
    }
  }
  return { startCoord: '', content: String(board) }
}

function renderBoardContent(board) {
  const { content } = parseBoard(board)
  if (!content) return ''
  let result = String(content)
  // 处理 $$...$$（display mode）
  result = result.replace(/\$\$([\s\S]+?)\$\$/g, (match, expr) => {
    try {
      return katex.renderToString(expr.trim(), { throwOnError: false, displayMode: true })
    } catch { return match }
  })
  // 处理 $...$（inline mode）
  result = result.replace(/\$([^\$\n]+?)\$/g, (match, expr) => {
    try {
      return katex.renderToString(expr.trim(), { throwOnError: false })
    } catch { return match }
  })
  // 处理裸 LaTeX（包含 \frac \begin \sqrt 等）
  if (/\\(frac|begin|sqrt|sum|int|lim|boxed|times|div|cdot|leq|geq|neq|approx|pm|infty|alpha|beta|gamma|delta|theta|lambda|pi|perp|parallel|angle|triangle|odot|text|mathrm|mathbf|mathcal|mathbb|operatorname|over)/.test(result)) {
    try {
      return katex.renderToString(result, { throwOnError: false })
    } catch { return result }
  }
  return result
}

const columns = [
  { title: '#', key: 'index', width: 50, fixed: 'left' },
  { title: '环节', key: 'stage', width: 80, fixed: 'left' },
  { title: '语音口播稿', key: 'speech' },
  { title: '板书内容', key: 'board' },
  { title: '板书动作', key: 'actionSpec', width: 110 },
  { title: '操作', key: 'operations', width: 100, fixed: 'right' },
]

const tableRows = computed(() => rows.value.map((row, index) => ({ ...row, _rowKey: `v2-${index}` })))
const problemTypeLabel = computed(() => ({
  geometry: '几何题',
  calculation: '计算题',
  word: '应用题',
}[handoff.value?.problemType] || handoff.value?.problemType || '未确认'))
const pureTextLabel = computed(() => (handoff.value?.imageKind || 'text_only') === 'text_only' ? '是' : '否')
const boardFocusLabel = computed(() => ({
  geometry_diagram: '几何图解',
  calculation_process: '演算过程',
  relation_understanding: '关系理解',
  mixed: '综合分析',
}[handoff.value?.boardFocus] || handoff.value?.boardFocus || '未确认'))
const relatedKnowledge = computed(() => Array.isArray(handoff.value?.relatedKnowledge)
  ? handoff.value.relatedKnowledge
  : [])
const knowledgeAnalysis = computed(() => handoff.value?.knowledgeAnalysis || null)
const coreKnowledge = computed(() => Array.isArray(knowledgeAnalysis.value?.coreKnowledge)
  ? knowledgeAnalysis.value.coreKnowledge
  : [])
const selectedKnowledge = ref(null)
const keyFormulaList = computed(() => Array.isArray(knowledgeAnalysis.value?.keyFormulaList)
  ? knowledgeAnalysis.value.keyFormulaList
  : [])
const uncertainItems = computed(() => Array.isArray(handoff.value?.uncertainItems)
  ? handoff.value.uncertainItems
  : [])
const suggestedLayoutLabel = computed(() => ({
  left_right: '左右布局',
  top_bottom: '上下布局',
}[handoff.value?.suggestedLayout?.layout] || handoff.value?.suggestedLayout?.layout || '无'))
const confirmedAtLabel = computed(() => formatDisplayTime(handoff.value?.confirmedAt))
const zoneParameterRows = computed(() => {
  const anchors = handoff.value?.zoneAnchors || {}
  const labels = { question: '题目区', analysis: '分析区', solution: '解答区', summary: '总结区' }
  return Object.entries(labels).map(([key, label]) => ({
    key,
    label,
    value: formatRegion(anchors[key]?.regionStartCoord),
  }))
})
const handoffFlowSteps = computed(() => [
  { title: '识别题目', status: 'finish', description: '第1步已确认' },
  { title: '判断题型', status: handoff.value?.problemType ? 'finish' : 'wait', description: problemTypeLabel.value },
  { title: '画布排版', status: handoff.value?.boardPlan ? 'finish' : 'wait', description: '真画布与四区布局' },
  {
    title: '知识关联',
    status: relatedKnowledge.value.length ? 'finish' : 'wait',
    description: relatedKnowledge.value.length ? `${relatedKnowledge.value.length} 条可选参考` : '可选，按题目判断',
  },
  { title: '组装输入', status: 'finish', description: '题目、图片、布局、工具' },
  {
    title: '待发送生成',
    status: state.value === 'generating' ? 'process' : rows.value.length ? 'finish' : 'wait',
    description: state.value === 'generating'
      ? '正在生成 Agent B 五字段'
      : rows.value.length
        ? `已生成 ${rows.value.length} 行`
        : '准备就绪 · 点击生成',
  },
])

function formatDisplayTime(value) {
  const date = value ? new Date(value) : new Date()
  return Number.isNaN(date.valueOf()) ? String(value || '') : date.toLocaleString('zh-CN', { hour12: false })
}

function displayValue(value) {
  return typeof value === 'string' ? value : JSON.stringify(value)
}

function formatRegion(region) {
  if (!region) return '未规划'
  const pct = (value) => Number(Number(value).toFixed(2))
  const size = region.w == null ? '' : `，宽 ${pct(region.w)}%${region.h == null ? '' : `，高 ${pct(region.h)}%`}`
  return `起点 (${pct(region.x)}%, ${pct(region.y)}%)${size}`
}

// async function persistTypographyConfig() {
//   saveBoardTypographyConfig(typography)
// }

function invalidateCheck() {
  checkRunId += 1
  checkState.value = 'idle'
  pendingCheckRows.value = null
}

function updateRow(index, field, value) {
  invalidateCheck()
  rows.value[index] = { ...rows.value[index], [field]: value }
  if (field === 'speech' || field === 'stage') rows.value = applyAgentBV2Timeline(rows.value)
}

// 编辑 board.content 时保持 startCoord 不变（v2.0 结构化 board）
function updateBoardContent(index, content) {
  invalidateCheck()
  const current = parseBoard(rows.value[index].board)
  rows.value[index] = {
    ...rows.value[index],
    board: { startCoord: current.startCoord, content },
  }
}

// 编辑 board.startCoord 时保持 content 不变
function updateBoardStartCoord(index, startCoord) {
  invalidateCheck()
  const current = parseBoard(rows.value[index].board)
  rows.value[index] = {
    ...rows.value[index],
    board: { startCoord: startCoord || '', content: current.content },
  }
}

function insertRowAfter(index) {
  invalidateCheck()
  const newRow = {
    stage: rows.value[index]?.stage || '分析',
    speech: '',
    board: { startCoord: '', content: '' },
    actionSpec: [],
  }
  rows.value.splice(index + 1, 0, newRow)
  rows.value = applyAgentBV2Timeline(rows.value)
  message.success('已在下方插入空白行，快来写下补充内容吧 ╰(๑◕ ▿ ◕๑)╯')
}

function deleteRow(index) {
  if (rows.value.length <= 1) {
    message.warning('不能全部删完哦，最少要保留一行内容哈 ฅ(⌯꒦ິ³꒦ິ⌯)ฅ')
    return
  }
  invalidateCheck()
  rows.value.splice(index, 1)
  rows.value = applyAgentBV2Timeline(rows.value)
  message.success('已成功删除该行 ٩(｡•ω•｡)و')
}

function actionLabel(entry) {
  const action = entry?.action
  if (!action) return '能力缺口'
  return [action.tool, action.action].filter(Boolean).join(' · ')
}

function actionContent(entry) {
  if (entry?.capabilityGap) return entry.capabilityGap.need
  const action = entry?.action || {}
  return action.content || action.target?.exactText || ''
}

// B 生成缓存：localStorage，24小时过期，Shift+点击强制刷新
const B_CACHE_PREFIX = 'b-gen:'
const B_CACHE_TTL = 24 * 60 * 60 * 1000

function bCacheKey() {
  const h = handoff.value || {}
  // 知识点摘要：取前3个知识点的名称，避免只取数量导致换知识点命中旧缓存
  const knowledgeDigest = Array.isArray(h.relatedKnowledge)
    ? h.relatedKnowledge.slice(0, 3).map(k => typeof k === 'string' ? k : (k.knowledgePoint || k.name || '')).join(',')
    : ''
  // knowledgeAnalysis 摘要：取 teachingFocus 前80字
  const analysisDigest = h.knowledgeAnalysis?.teachingFocus
    ? String(h.knowledgeAnalysis.teachingFocus).slice(0, 80)
    : ''
  return B_CACHE_PREFIX + [
    h.problemText?.slice(0, 80) || '',
    h.problemType || '',
    h.boardFocus || '',
    knowledgeDigest,
    analysisDigest,
    h.stageRatioSuggestion?.type || '',
    h.boardPlan?.question?.x || '',
    selectedSkillId.value || '',
    customSystemPrompt.value ? 'custom' : 'default',
  ].join('|')
}

function bCacheGet() {
  try {
    const raw = localStorage.getItem(bCacheKey())
    if (!raw) return null
    const data = JSON.parse(raw)
    if (Date.now() - data.timestamp > B_CACHE_TTL) {
      localStorage.removeItem(bCacheKey())
      return null
    }
    return data
  } catch { return null }
}

function bCacheSet(rows, model) {
  try {
    localStorage.setItem(bCacheKey(), JSON.stringify({ rows, model, timestamp: Date.now() }))
  } catch { /* 存储满了忽略 */ }
}

async function generateRows(force = false) {
  if (state.value === 'generating') return
  if (!force) {
    const cached = bCacheGet()
    if (cached) {
      rows.value = cached.rows
      generatedModel.value = cached.model
      state.value = 'ready'
      message.info(`已使用缓存结果（${cached.rows.length}行），Shift+点击可强制刷新`)
      return
    }
  }
  invalidateCheck()
  state.value = 'generating'
  errorText.value = ''
  try {
    // B 生成只请求剧本；不加载板书字体或发起字体网络请求。
    const result = await generateAgentBV2Rows({
      handoff: handoff.value,
      systemPrompt: customSystemPrompt.value,
      skillId: selectedSkillId.value,
      rowGapMs: canvasParams.value.rowGapMs,
      canvasParams: { ...canvasParams.value },
    })
    rows.value = result.rows
    generatedModel.value = result.model
    state.value = 'ready'
    bCacheSet(result.rows, result.model)
    message.success(`已生成 ${rows.value.length} 行五字段执行表`)
  } catch (error) {
    state.value = 'error'
    errorText.value = error?.message || String(error)
    message.error(errorText.value)
  }
}

async function checkRows() {
  if (!rows.value.length || checkState.value === 'checking') return
  const runId = ++checkRunId
  checkState.value = 'checking'
  errorText.value = ''
  checkChanges.value = []
  try {
    const result = await checkAgentRows({
      rows: rows.value,
    })
    if (runId !== checkRunId) return
    pendingCheckRows.value = result.rows
    checkChanges.value = result.changes
    checkState.value = 'ready'
    checkResultOpen.value = true
    checkFailedFallback.value = result.checkStatus === 'failed_fallback'
    if (checkFailedFallback.value) {
      message.warning(`Check Agent 返回格式异常，已回退原表（${result.checkError || '未提供错误详情'}）。当前显示的是原表，未做任何修改。`)
    } else {
      message.success(result.changes.length ? `Check 完成，发现 ${result.changes.length} 处建议` : 'Check 完成，未发现需要修正的内容')
    }
  } catch (error) {
    if (runId !== checkRunId) return
    checkState.value = 'error'
    errorText.value = error?.message || String(error)
    message.error(errorText.value)
  }
}

function applyCheckChanges() {
  if (!pendingCheckRows.value || !checkChanges.value.length) return
  const changeCount = checkChanges.value.length
  rows.value = pendingCheckRows.value
  // 同步写回服务端文件（文件即真相源）
  applyCheckResult(pendingCheckRows.value).catch(() => {
    message.warning('本地已应用，但保存到服务端失败，刷新后会恢复为原版本')
  })
  pendingCheckRows.value = null
  checkChanges.value = []
  checkState.value = 'idle'
  checkResultOpen.value = false
  checkFailedFallback.value = false
  message.success(`已应用 ${changeCount} 处 Check 修改`)
}

function discardCheckChanges() {
  pendingCheckRows.value = null
  checkResultOpen.value = false
  checkFailedFallback.value = false
}

// 还原到 Check 之前的原始版本
async function revertCheck() {
  try {
    const result = await revertCheckResult()
    rows.value = result.rows || []
    checkState.value = 'idle'
    message.success('已还原到 Check 之前的版本')
  } catch (error) {
    message.error(error?.message || '还原失败')
  }
}

function exportElements() {
  if (!rows.value.length) return
  exportElementsMarkdown(rows.value, {
    problemText: handoff.value?.problemText || '',
    model: generatedModel.value || agentBApiConfig.model || '',
    generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
    canvasParams: JSON.parse(JSON.stringify(canvasParams.value)),
    handoffCanvasParams: handoff.value?.canvasParams || null,
    handoffBoardPlan: handoff.value?.boardPlan || null,
  })
  message.success('完整要素表 MD 已导出')
}

function exportSpeech() {
  if (!rows.value.length) return
  exportSpeechMarkdown(rows.value, {
    problemText: handoff.value?.problemText || '',
    model: generatedModel.value || agentBApiConfig.model || '',
    generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
    handoffCanvasParams: handoff.value?.canvasParams || null,
  })
  message.success('口播稿 MD 已导出')
}

function exportStoryboard() {
  if (!rows.value.length) return
  exportStoryboardMarkdown(rows.value, {
    problemText: handoff.value?.problemText || '',
    model: generatedModel.value || agentBApiConfig.model || '',
    generatedAt: new Date().toLocaleString('zh-CN', { hour12: false }),
    handoffCanvasParams: handoff.value?.canvasParams || null,
    handoffBoardPlan: handoff.value?.boardPlan || null,
  })
  message.success('分镜表 MD 已导出')
}

// 知识点修缮：手动触发，调 POST /api/knowledge/refine，成功后弹结果弹窗，用户点应用才更新
async function refineKnowledge() {
  if (refineLoading.value) return
  refineLoading.value = true
  try {
    const resp = await fetch('/api/knowledge/refine', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        endpoint: userApiConfig.endpoint,
        model: userApiConfig.model,
        apiKey: userApiConfig.apiKey,
      }),
    })
    const result = await resp.json()
    if (result.ok && result.handoff) {
      refineResult.value = result
      refineResultOpen.value = true
    } else {
      message.error(result.error || '优化失败')
    }
  } catch (error) {
    message.error(error?.message || '优化异常')
  } finally {
    refineLoading.value = false
  }
}

// 应用修缮结果：更新 localHandoff，参数表动态读取自动刷新（不用刷新页面）
function applyRefine() {
  if (!refineResult.value?.handoff) return
  // refineResult 被 Vue ref 代理，handoff 对象带 ReactiveEffect 循环引用
  // 必须 toRaw + 深拷贝脱壳后再赋值，否则响应式可能失效
  localHandoff.value = JSON.parse(JSON.stringify(toRaw(refineResult.value.handoff)))
  refineResultOpen.value = false
  refineResult.value = null
  message.success('知识点已优化，参数表已更新')
}

// 保留原文：不更新，关闭弹窗
function keepOriginalRefine() {
  refineResultOpen.value = false
  refineResult.value = null
}

function formatRefineField(value) {
  if (value == null) return '（无）'
  if (Array.isArray(value)) return value.map((item, i) => `${i + 1}. ${typeof item === 'string' ? item : JSON.stringify(item)}`).join('\n')
  if (typeof value === 'object') return JSON.stringify(value, null, 2)
  return String(value)
}

// 比较修缮前后字段是否有变化
function isRefineFieldEqual(original, refined) {
  if (original == null && refined == null) return true
  if (original == null || refined == null) return false
  return JSON.stringify(original) === JSON.stringify(refined)
}

</script>

<template>
  <a-layout class="qh-page">
    <QhPageHeader
      step-label="第 2 步 · Agent B"
      subtitle="题目信息 → 五字段"
      show-back
      @back="emit('back-to-step1')"
    >
      <template #actions>
        <a-button
          title="可用工具"
          @click="toolsOpen = !toolsOpen"
        >
          <template #icon>
            <ToolOutlined />
          </template>
          工具
        </a-button>
        <!-- B 是剧本页；板书字体设置冻结，等待独立播放器立项。 -->
      </template>
    </QhPageHeader>

    <a-layout-content class="qh-page-content">
      <a-space
        direction="vertical"
        size="middle"
        style="width:100%"
      >
        <a-card
          class="qh-surface-card"
          size="small"
        >
          <template #title>
            Agent B 输入交接台
          </template>
          <template #extra>
            <a-button
              type="primary"
              size="small"
              :loading="refineLoading"
              @click="refineKnowledge"
            >
              优化确认
            </a-button>
          </template>
          <a-typography-text type="secondary">
            Agent A 交接摘要
          </a-typography-text>
          <a-steps
            class="qh-handoff-steps"
            size="small"
            :items="handoffFlowSteps"
          />
          <a-space
            wrap
            size="small"
            style="margin: 4px 0"
          >
            <a-tag>题目 1 道</a-tag>
            <a-tag>画布分区 {{ handoff?.boardPlan ? 4 : 0 }} 个</a-tag>
            <a-tag>知识参考 {{ relatedKnowledge.length }} 条</a-tag>
            <a-tag>工具能力 {{ toolCatalog.tools.length }} 项</a-tag>
          </a-space>
          <div class="qh-section-title">
            题目信息
          </div>
          <a-descriptions
            bordered
            size="small"
            :column="3"
            :label-style="{ width: '100px' }"
          >
            <a-descriptions-item label="题目类型">
              {{ problemTypeLabel }}<span class="qh-field-key">problemType</span>
            </a-descriptions-item>
            <a-descriptions-item label="是否纯文本">
              {{ pureTextLabel }}<span class="qh-field-key">imageKind</span>
            </a-descriptions-item>
            <a-descriptions-item label="板书侧重">
              {{ boardFocusLabel }}<span class="qh-field-key">boardFocus</span>
            </a-descriptions-item>
            <a-descriptions-item label="交接时间">
              {{ confirmedAtLabel }}<span class="qh-field-key">confirmedAt</span>
            </a-descriptions-item>
            <a-descriptions-item label="建议年级">
              {{ handoff?.suggestedGrade || '未判断' }}<span class="qh-field-key">suggestedGrade</span>
            </a-descriptions-item>
            <a-descriptions-item label="建议布局">
              {{ suggestedLayoutLabel }}<span class="qh-field-key">suggestedLayout</span>
            </a-descriptions-item>
            <a-descriptions-item label="画布参数" :span="3">
              <template v-if="handoff?.canvasParams">
                <span style="font-size: 12px; color: #595959; line-height: 1.8;">
                  尺寸 {{ handoff.canvasParams.canvasSize.width }}×{{ handoff.canvasParams.canvasSize.height }}px ·
                  题目字号 {{ handoff.canvasParams.fontSize.question.px }}px({{ handoff.canvasParams.fontSize.question.color }}) ·
                  分析/解答/总结 {{ handoff.canvasParams.fontSize.analysis.px }}px(分析{{ handoff.canvasParams.fontSize.analysis.color }}/解答{{ handoff.canvasParams.fontSize.solution.color }}/总结{{ handoff.canvasParams.fontSize.summary.color }}) ·
                  行高 题目{{ handoff.canvasParams.lineHeight.question }}/其他{{ handoff.canvasParams.lineHeight.others }} ·
                  板书速度 {{ handoff.canvasParams.boardSpeed }} ·
                  动作速度 {{ handoff.canvasParams.actionSpeed }}
                </span>
                <span class="qh-field-key">canvasParams</span>
              </template>
              <span v-else style="font-size: 12px; color: #bfbfbf;">未携带画布参数</span>
            </a-descriptions-item>
          </a-descriptions>

          <div class="qh-section-title">
            知识点
          </div>
          <a-descriptions
            bordered
            size="small"
            :column="2"
            :label-style="{ width: '100px' }"
          >
            <a-descriptions-item label="知识分析">
              {{ coreKnowledge.length }} 个核心知识点 · {{ keyFormulaList.length }} 条公式<span class="qh-field-key">knowledgeAnalysis</span>
            </a-descriptions-item>
            <a-descriptions-item label="交接来源">
              {{ handoff?.agentPageName || 'Agent A' }} · {{ handoff?.agentCapability || '未声明能力' }} · v{{ handoff?.handoffVersion || 1 }}<span class="qh-field-key">agentPageName/agentCapability/handoffVersion</span>
            </a-descriptions-item>
            <a-descriptions-item
              label="知识关联点"
              :span="2"
            >
              <a-space
                wrap
                size="small"
              >
                <a-tag
                  v-if="relatedKnowledge.length === 0"
                  color="default"
                >
                  未优化
                </a-tag>
                <a-tag
                  v-for="(item, idx) in relatedKnowledge"
                  :key="typeof item === 'string' ? idx : (item['编号'] || item['知识点'])"
                  color="blue"
                >
                  {{ typeof item === 'string' ? item : (item['知识点'] || '未命名知识点') }}
                </a-tag>
              </a-space><span class="qh-field-key">relatedKnowledge</span>
            </a-descriptions-item>
            <a-descriptions-item
              v-if="knowledgeAnalysis?.teachingFocus"
              label="教学重点"
              :span="2"
            >
              {{ knowledgeAnalysis.teachingFocus }}<span class="qh-field-key">knowledgeAnalysis.teachingFocus</span>
            </a-descriptions-item>
            <a-descriptions-item
              v-if="keyFormulaList.length"
              label="关键公式"
              :span="2"
            >
              <a-space
                wrap
                size="small"
              >
                <a-tag
                  v-for="formula in keyFormulaList"
                  :key="formula"
                  color="blue"
                >
                  {{ formula }}
                </a-tag>
              </a-space><span class="qh-field-key">knowledgeAnalysis.keyFormulaList</span>
            </a-descriptions-item>
            <a-descriptions-item
              v-if="uncertainItems.length"
              label="待确认项"
              :span="2"
            >
              <a-space
                wrap
                size="small"
              >
                <a-tag
                  v-for="item in uncertainItems"
                  :key="displayValue(item)"
                  color="orange"
                >
                  {{ displayValue(item) }}
                </a-tag>
              </a-space><span class="qh-field-key">uncertainItems</span>
            </a-descriptions-item>
            <a-descriptions-item
              label="使用方式"
              :span="2"
            >
              <a-typography-text type="secondary">
                Agent A 只给软建议，不是门槛或强制清单；锚定题目与四区骨架后，由 Agent B 自主取舍、改写和补充。
              </a-typography-text>
            </a-descriptions-item>
          </a-descriptions>

          <div class="qh-section-title">
            布局参数
          </div>
          <a-descriptions
            bordered
            size="small"
            :column="2"
            :label-style="{ width: '100px' }"
          >
            <a-descriptions-item label="四区布局">
              {{ handoff?.boardPlan ? '已确认' : '未确认' }}<span class="qh-field-key">boardPlan</span>
            </a-descriptions-item>
            <a-descriptions-item
              label="四区参数"
              :span="2"
            >
              <a-space
                wrap
                size="small"
              >
                <a-tag
                  v-for="zone in zoneParameterRows"
                  :key="zone.key"
                >
                  {{ zone.label }}：{{ zone.value }}
                </a-tag>
              </a-space><span class="qh-field-key">zoneAnchors/boardPlan</span>
            </a-descriptions-item>
          </a-descriptions>

          <div class="qh-section-title">
            交接元数据
          </div>
          <a-descriptions
            bordered
            size="small"
            :column="2"
            :label-style="{ width: '100px' }"
          >
            <a-descriptions-item label="画布截图">
              <div v-if="handoff?.screenshotUrl" style="font-size: 12px; font-family: monospace; color: #1677ff;">
                {{ handoff.screenshotUrl }}
              </div>
              <a-typography-text v-else type="secondary">
                暂无
              </a-typography-text>
            </a-descriptions-item>
            <a-descriptions-item label="知识库地址">
              <div style="font-size: 12px; font-family: monospace; color: #1677ff;">
                {{ handoff?.knowledgeBasePath || 'doc/knowledge-a.compact.json' }}
              </div>
            </a-descriptions-item>
          </a-descriptions>

          <!-- 题型配比建议（SK-06 绑定CU） -->
          <div v-if="handoff?.stageRatioSuggestion" class="stage-ratio-suggestion">
            <div class="qh-section-title">
              题型配比建议
            </div>
            <a-descriptions
              bordered
              size="small"
              :column="2"
              :label-style="{ width: '100px' }"
            >
              <a-descriptions-item label="题型分类">
                <a-tag color="purple">
                  {{ handoff.stageRatioSuggestion.cuCode }} · {{ handoff.stageRatioSuggestion.type }} · {{ handoff.stageRatioSuggestion.category }}
                </a-tag>
                <a-tag v-if="handoff.stageRatioSuggestion.confidence === 'high'" color="green">
                  高置信
                </a-tag>
                <a-tag v-else-if="handoff.stageRatioSuggestion.confidence === 'medium'" color="orange">
                  中置信
                </a-tag>
              </a-descriptions-item>
              <a-descriptions-item label="对应题型/知识点">
                <span style="font-size: 12px; color: #595959;">{{ handoff.stageRatioSuggestion.topicExamples }}</span>
              </a-descriptions-item>
              <a-descriptions-item label="配比本质">
                {{ handoff.stageRatioSuggestion.essence }}
              </a-descriptions-item>
              <a-descriptions-item label="分析占比">
                <span style="color: #cf1322; font-weight: 500;">{{ handoff.stageRatioSuggestion.suggestedRatio.analysis }}</span>
              </a-descriptions-item>
              <a-descriptions-item label="解答占比">
                <span style="color: #1677ff; font-weight: 500;">{{ handoff.stageRatioSuggestion.suggestedRatio.solution }}</span>
              </a-descriptions-item>
              <a-descriptions-item label="总结占比">
                <span style="color: #389e0d; font-weight: 500;">{{ handoff.stageRatioSuggestion.suggestedRatio.summary }}</span>
              </a-descriptions-item>
              <a-descriptions-item label="读题+开场+结束">
                <span style="color: #8c8c8c; font-weight: 500;">{{ handoff.stageRatioSuggestion.suggestedRatio.introAndClosing }}</span>
              </a-descriptions-item>
            </a-descriptions>
          </div>

          <div
            v-if="coreKnowledge.length"
            class="knowledge-chips"
          >
            <a-tag
              v-for="item in coreKnowledge"
              :key="item.knowledgeId || item.knowledgePoint"
              color="blue"
              class="knowledge-chip"
              @click="selectedKnowledge = item"
            >
              {{ item.knowledgePoint || '未命名知识点' }}
            </a-tag>
          </div>
        </a-card>

        <a-alert
          v-if="errorText"
          type="error"
          show-icon
          :message="errorText"
        />


        <a-row :gutter="[16, 16]">
          <a-col :span="24">
            <a-card
              title="已确认题目"
              class="qh-surface-card"
            >
              <template #extra>
                <a-tag color="blue">
                  {{ problemTypeLabel }}
                </a-tag>
              </template>
              <a-typography-paragraph>{{ handoff?.problemText }}</a-typography-paragraph>
            </a-card>
          </a-col>
        </a-row>

        <a-card class="qh-surface-card">
          <template #title>
            <a-space>
              <span>五字段执行表</span>
              <a-tag color="blue">
                {{ problemTypeLabel }}
              </a-tag>
              <a-tag color="purple" title="当前使用的提示词">
                {{ currentSkillName }}
              </a-tag>
              <a-tag
                v-if="generatedModel"
                color="green"
              >
                {{ generatedModel }}
              </a-tag>
              <a-tag v-if="rows.length">
                {{ rows.length }} 行
              </a-tag>
            </a-space>
          </template>
          <template #extra>
            <a-space
              size="middle"
              wrap
            >
              <a-typography-text type="secondary">
                主工作区 · {{ canvasParams.speechSpeed }}字/分估时
              </a-typography-text>
              <a-button
                :disabled="!rows.length || state === 'generating'"
                :loading="checkState === 'checking'"
                title="手动调用独立 Check Agent，润色当前表格内容"
                @click="checkRows"
              >
                <template #icon>
                  <CheckCircleOutlined />
                </template>
                Check Agent
              </a-button>
              <a-button
                :disabled="!rows.length"
                title="还原到 Check 之前的原始版本"
                @click="revertCheck"
              >
                <template #icon>
                  <RollbackOutlined />
                </template>
                还原
              </a-button>
              <a-button
                :disabled="!rows.length"
                title="导出包含行标识、口播、板书和完整动作参数的 Markdown 要素表"
                @click="exportElements"
              >
                <template #icon>
                  <DownloadOutlined />
                </template>
                导出完整要素表 MD
              </a-button>
              <a-button
                :disabled="!rows.length"
                title="将当前口播稿保存为 Markdown 文件"
                @click="exportSpeech"
              >
                <template #icon>
                  <DownloadOutlined />
                </template>
                一键导出口播稿 MD
              </a-button>
              <a-button
                :disabled="!rows.length"
                title="按环节分块导出分镜表（stage + 行号标识 + 口播 + 板书 + 动作摘要）"
                @click="exportStoryboard"
              >
                <template #icon>
                  <DownloadOutlined />
                </template>
                导出时序分镜表 MD
              </a-button>
              <a-button
                title="编辑/切换提示词"
                @click="promptEditOpen = true"
              >
                <template #icon>
                  <SettingOutlined />
                </template>
                提示词
              </a-button>
              <a-button
                type="primary"
                :loading="state === 'generating'"
                title="Shift+点击强制刷新缓存"
                @click="(e) => generateRows(e.shiftKey)"
              >
                <template #icon>
                  <ThunderboltOutlined />
                </template>
                生成 Agent B 五字段
              </a-button>
            </a-space>
          </template>

          <!-- 画布参数面板 -->
          <div class="canvas-params-bar">
            <a-space wrap size="small" align="center">
              <span class="params-label">画布参数：</span>
              <a-select
                v-model:value="canvasParams.coordinateMode"
                size="small"
                style="width: 100px"
                title="坐标计算方式"
              >
                <a-select-option value="percentage">百分比</a-select-option>
                <a-select-option value="pixel">像素</a-select-option>
              </a-select>
              <a-input-number
                v-model:value="canvasParams.questionFontSize"
                size="small"
                :min="12"
                :max="60"
                addon-before="题目字号"
                addon-after="px"
                style="width: 150px"
              />
              <a-input
                v-model:value="canvasParams.questionFontFamily"
                size="small"
                placeholder="字体"
                style="width: 200px"
                title="题目字体"
              />
              <a-input-number
                v-model:value="canvasParams.questionLineHeight"
                size="small"
                :min="1"
                :max="3"
                :step="0.1"
                addon-before="行距"
                style="width: 120px"
              />
              <a-input-number
                v-model:value="canvasParams.rowGapMs"
                size="small"
                :min="0"
                :max="2000"
                :step="100"
                addon-before="row间隔"
                addon-after="ms"
                style="width: 140px"
              />
              <a-input-number
                v-model:value="canvasParams.speechSpeed"
                size="small"
                :min="80"
                :max="300"
                :step="10"
                addon-before="音频速度"
                addon-after="字/分"
                style="width: 150px"
              />
              <a-tag color="blue" title="四个stage区域坐标">
                四区坐标：{{ canvasParams.coordinateMode === 'percentage' ? '百分比' : '像素' }}
              </a-tag>
            </a-space>
          </div>

          <div
            v-if="!rows.length"
            style="padding: 20px 0; display:flex; align-items:center; gap:11px;"
          >
            <a-typography-text type="secondary">
              题目信息已就绪，点击右上角"生成"按钮
            </a-typography-text>
          </div>
          <a-table
            v-else
            :columns="columns"
            :data-source="tableRows"
            row-key="_rowKey"
            :pagination="false"
            size="small"
            bordered
          >
            <template #bodyCell="{ column, record, index }">
              <a-typography-text
                v-if="column.key === 'index'"
                type="secondary"
                style="font-size: 12px; font-weight: 600; display: block; text-align: center; color: #8c8c8c"
              >
                {{ index + 1 }}
              </a-typography-text>
              <a-popover
                v-else-if="column.key === 'stage'"
                trigger="click"
                placement="bottomLeft"
                :overlayStyle="{ minWidth: '100px' }"
              >
                <template #content>
                  <a-space direction="vertical" size="2" style="display: flex;">
                    <a-button
                      v-for="opt in ['题目', '分析', '解答', '总结']"
                      :key="opt"
                      size="small"
                      :type="record.stage === opt ? 'primary' : 'text'"
                      style="text-align: left; justify-content: flex-start;"
                      @click="updateRow(index, 'stage', opt)"
                    >
                      {{ opt }}
                    </a-button>
                  </a-space>
                </template>
                <a-tag
                  :color="stageTagColors[record.stage]"
                  style="cursor: pointer; font-size: 12px; padding: 2px 10px; border-radius: 4px; margin: 0;"
                >
                  {{ record.stage }}
                </a-tag>
              </a-popover>
              <a-popover
                v-else-if="column.key === 'actionSpec' && record.actionSpec.length"
                trigger="click"
                placement="left"
              >
                <template #content>
                  <a-list
                    :data-source="record.actionSpec"
                    size="small"
                    style="width: 360px; max-height: 420px; overflow: auto"
                  >
                    <template #renderItem="{ item }">
                      <a-list-item>
                        <a-space
                          direction="vertical"
                          size="small"
                        >
                          <a-space
                            :size="4"
                            wrap
                          >
                            <a-tag
                              v-if="item.action?.order"
                              color="blue"
                            >
                              #{{ item.action.order }}
                            </a-tag>
                            <a-tag>{{ actionLabel(item) }}</a-tag>
                          </a-space>
                          <a-typography-text>{{ actionContent(item) }}</a-typography-text>
                        </a-space>
                      </a-list-item>
                    </template>
                  </a-list>
                </template>
                <a-tag
                  color="processing"
                  style="cursor: pointer"
                >
                  {{ record.actionSpec.length }} 个动作
                </a-tag>
              </a-popover>
              <span
                v-else-if="column.key === 'actionSpec'"
                style="color: #bfbfbf; font-size: 11px"
              >—</span>
              <!-- board 列：非编辑状态显示 起手坐标(小字号灰)+KaTeX渲染，点击进入编辑 -->
              <div
                v-else-if="column.key === 'board'"
                class="board-cell"
              >
                <div
                  v-if="editingBoardIndex !== index"
                  class="board-rendered"
                  @click="editingBoardIndex = index"
                >
                  <div v-if="parseBoard(record.board).startCoord" class="board-coord">
                    {{ parseBoard(record.board).startCoord }}
                  </div>
                  <div v-html="renderBoardContent(record.board)" />
                </div>
                <div v-else class="board-edit-wrap">
                  <a-input
                    :value="parseBoard(record.board).startCoord"
                    size="small"
                    placeholder="起手坐标，如 [10%, 45%]"
                    style="margin-bottom: 4px; font-size: 11px; font-family: monospace;"
                    @change="(event) => updateBoardStartCoord(index, event.target.value)"
                  />
                  <a-textarea
                    :value="parseBoard(record.board).content"
                    :auto-size="{ minRows: 2, maxRows: 8 }"
                    style="font-size: 12px"
                    @change="(event) => updateBoardContent(index, event.target.value)"
                  />
                  <div style="margin-top: 4px; text-align: right;">
                    <a-button size="small" type="primary" @click="editingBoardIndex = -1">
                      完成
                    </a-button>
                  </div>
                </div>
              </div>
              <div v-else-if="column.key === 'operations'">
                <a-space size="small">
                  <a-button
                    type="primary"
                    shape="circle"
                    size="small"
                    title="在下方新增一行"
                    @click="insertRowAfter(index)"
                  >
                    <template #icon>
                      <PlusOutlined />
                    </template>
                  </a-button>
                  <a-popconfirm
                    title="确定要删除这一行吗？"
                    ok-text="确定"
                    cancel-text="取消"
                    @confirm="deleteRow(index)"
                  >
                    <a-button
                      type="primary"
                      danger
                      shape="circle"
                      size="small"
                      title="删除这一行"
                    >
                      <template #icon>
                        <DeleteOutlined />
                      </template>
                    </a-button>
                  </a-popconfirm>
                </a-space>
              </div>
              <a-textarea
                v-else-if="column.key === 'speech'"
                :value="record.speech"
                :auto-size="{ minRows: 2, maxRows: 8 }"
                style="font-size: 12px"
                @change="(event) => updateRow(index, 'speech', event.target.value)"
              />
            </template>
          </a-table>
        </a-card>

        <a-card
          v-if="toolsOpen"
          title="可用工具说明"
          class="qh-surface-card qh-tool-card"
          size="small"
        >
          <template #extra>
            <a-typography-text type="secondary">
              单手串行 · 随口播触发 · 坐标单位百分比
            </a-typography-text>
          </template>
          <a-row :gutter="[12, 12]">
            <a-col
              v-for="item in toolReferenceRows"
              :key="item.key"
              :span="24"
            >
              <a-card
                size="small"
                class="qh-tool-item"
              >
                <a-row
                  :gutter="12"
                  align="top"
                >
                  <a-col :span="6">
                    <div class="qh-tool-preview">
                      <svg
                        v-if="item.key === 'underline'"
                        viewBox="0 0 120 40"
                        width="100%"
                        height="40"
                      >
                        <text
                          x="10"
                          y="18"
                          font-size="14"
                          fill="#263238"
                          font-family="serif"
                        >标记的文字</text>
                        <path
                          d="M8 26 Q 60 38 112 26"
                          :stroke="BOARD_MARK_COLORS.red"
                          stroke-width="2"
                          fill="none"
                          stroke-linecap="round"
                        />
                      </svg>
                      <svg
                        v-else-if="item.key === 'highlight'"
                        viewBox="0 0 120 40"
                        width="100%"
                        height="40"
                      >
                        <rect
                          x="6"
                          y="8"
                          width="108"
                          height="22"
                          :fill="BOARD_MARK_COLORS.yellow"
                          opacity="0.4"
                          rx="3"
                        />
                        <text
                          x="10"
                          y="24"
                          font-size="14"
                          fill="#263238"
                          font-family="serif"
                        >高亮的文字</text>
                      </svg>
                      <svg
                        v-else-if="item.key === 'rough-line'"
                        viewBox="0 0 120 40"
                        width="100%"
                        height="40"
                      >
                        <path
                          d="M10 20 Q 60 18 110 22"
                          :stroke="ROUGH_DRAWING_COLORS.ink"
                          stroke-width="2"
                          fill="none"
                          stroke-linecap="round"
                        />
                      </svg>
                      <svg
                        v-else-if="item.key === 'rough-arrow'"
                        viewBox="0 0 120 40"
                        width="100%"
                        height="40"
                      >
                        <path
                          d="M10 20 Q 60 18 100 22"
                          :stroke="ROUGH_DRAWING_COLORS.red"
                          stroke-width="2"
                          fill="none"
                          stroke-linecap="round"
                        />
                        <path
                          d="M100 22 L 110 16 M 100 22 L 108 28"
                          :stroke="ROUGH_DRAWING_COLORS.red"
                          stroke-width="2"
                          fill="none"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </div>
                  </a-col>
                  <a-col :span="18">
                    <div class="qh-tool-title">
                      <a-tag color="blue">
                        {{ item.label }}
                      </a-tag>
                      <span class="qh-tool-tool-id">{{ item.tool }}</span>
                    </div>
                    <div class="qh-tool-summary">
                      {{ item.summary }}
                    </div>
                    <div class="qh-tool-fields">
                      <div
                        v-for="f in item.fields"
                        :key="f.name"
                        class="qh-tool-field"
                      >
                        <code class="qh-field-name">{{ f.name }}</code>
                        <span class="qh-field-value">{{ f.value }}</span>
                      </div>
                    </div>
                  </a-col>
                </a-row>
                <div
                  v-if="item.example"
                  class="qh-tool-example"
                >
                  <div class="qh-tool-example-label">
                    示例
                  </div>
                  <pre class="qh-tool-example-code">{{ item.example }}</pre>
                </div>
              </a-card>
            </a-col>
          </a-row>
          <a-divider style="margin: 12px 0" />
          <a-row :gutter="12">
            <a-col :span="12">
              <a-typography-title :level="5">
                通用参数
              </a-typography-title>
              <div class="qh-tool-common">
                <div><b>action.order</b>：全表唯一正整数，按播放顺序递增</div>
                <div><b>标记颜色</b>：下划线红色；高亮浅黄色</div>
                <div>
                  <b>直线 / 箭头颜色</b>：<a-tag color="default">
                    ink
                  </a-tag> <a-tag color="red">
                    red
                  </a-tag>
                </div>
                <div><b>笔画 strokeWidthId</b>：normal（细）/ emphasis（粗）</div>
              </div>
            </a-col>
            <a-col :span="12">
              <a-typography-title :level="5">
                可用区域
              </a-typography-title>
              <div class="qh-tool-common">
                <div>
                  <a-tag>question 题目区</a-tag> <a-tag color="orange">
                    analysis 分析区
                  </a-tag>
                </div>
                <div>
                  <a-tag color="green">
                    solution 解答区
                  </a-tag> <a-tag color="purple">
                    summary 总结区
                  </a-tag>
                </div>
                <div style="margin-top:6px;color:#8c8c8c;font-size:12px">
                  绘图工具四个区域都可以画；文字标记只能标记已有的文字
                </div>
              </div>
            </a-col>
          </a-row>
        </a-card>
      </a-space>
    </a-layout-content>
    <a-modal
      :open="Boolean(selectedKnowledge)"
      :title="selectedKnowledge?.knowledgePoint || '知识点详情'"
      width="720px"
      :footer="null"
      @cancel="selectedKnowledge = null"
    >
      <a-descriptions
        v-if="selectedKnowledge"
        bordered
        size="small"
        :column="1"
        class="knowledge-detail-table"
      >
        <a-descriptions-item label="编号">
          {{ selectedKnowledge.knowledgeId || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="学段 / 系列 / 类型">
          {{ [selectedKnowledge.rawKnowledgeRecord?.学段, selectedKnowledge.rawKnowledgeRecord?.系列, selectedKnowledge.rawKnowledgeRecord?.类型].filter(Boolean).join(' / ') || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="经典样题">
          {{ selectedKnowledge.rawKnowledgeRecord?.经典样题 || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="考点">
          {{ selectedKnowledge.examinationPoint || selectedKnowledge.rawKnowledgeRecord?.考点 || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="策略方法">
          {{ selectedKnowledge.strategy || selectedKnowledge.rawKnowledgeRecord?.策略方法 || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="讲解要点">
          {{ selectedKnowledge.rawKnowledgeRecord?.讲解要点举例 || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="易错点">
          {{ selectedKnowledge.commonMistakes?.join('；') || selectedKnowledge.rawKnowledgeRecord?.易错点 || '未提供' }}
        </a-descriptions-item>
        <a-descriptions-item label="公式">
          {{ selectedKnowledge.formula || '按本题判断' }}
        </a-descriptions-item>
        <a-descriptions-item label="总结归纳">
          {{ selectedKnowledge.summary || selectedKnowledge.rawKnowledgeRecord?.总结归纳 || '未提供' }}
        </a-descriptions-item>
      </a-descriptions>
    </a-modal>
    <a-modal
      v-model:open="checkResultOpen"
      title="Check Agent 润色结果"
      :width="760"
      @cancel="discardCheckChanges"
    >
      <div
        v-if="checkFailedFallback"
        class="qh-check-empty"
      >
        <WarningOutlined style="color: #faad14;" />
        <div>
          <strong>Check Agent 返回格式异常，已回退原表</strong>
          <p>当前五字段执行表保持原样，未做任何修改。</p>
        </div>
      </div>
      <div
        v-else-if="!checkChanges.length"
        class="qh-check-empty"
      >
        <CheckCircleOutlined />
        <div>
          <strong>未发现需要润色的内容</strong>
          <p>当前五字段执行表保持原样。</p>
        </div>
      </div>
      <a-list
        v-else
        bordered
        :data-source="checkChanges"
        class="qh-check-list"
      >
        <template #renderItem="{ item }">
          <a-list-item>
            <div class="qh-check-change">
              <a-space
                wrap
                size="small"
              >
                <a-tag color="blue">
                  第 {{ item.row || '?' }} 行
                </a-tag>
                <a-tag>{{ checkFieldLabels[item.field] || item.field }}</a-tag>
                <a-typography-text type="secondary">
                  {{ item.reason }}
                </a-typography-text>
              </a-space>
              <div class="qh-check-diff">
                <div>
                  <span>原文</span>
                  <p>{{ item.before || '（空）' }}</p>
                </div>
                <div>
                  <span>修正后</span>
                  <p>{{ item.after || '（空）' }}</p>
                </div>
              </div>
            </div>
          </a-list-item>
        </template>
      </a-list>
      <template #footer>
        <a-button @click="discardCheckChanges">
          保留原文
        </a-button>
        <a-button
          v-if="checkChanges.length"
          type="primary"
          @click="applyCheckChanges"
        >
          应用 {{ checkChanges.length }} 处修改
        </a-button>
      </template>
    </a-modal>

    <a-modal
      v-model:open="refineResultOpen"
      title="知识点修缮对比"
      :footer="null"
      width="900px"
      :destroy-on-close="true"
    >
      <a-alert
        v-if="refineResult?.refineOk === false"
        type="warning"
        :message="refineResult?.warning || 'AI 这次没返回标准格式，已保留原内容，可重试'"
        show-icon
        style="margin-bottom: 16px"
      />
      <div v-else>
        <div style="margin-bottom: 12px">
          <a-typography-text type="secondary" style="font-size: 12px">
            左侧为 Agent A 自动匹配结果，右侧为教研 Agent 提炼优化。对比后选择是否应用。
          </a-typography-text>
        </div>
        <a-descriptions
          bordered
          size="small"
          :column="1"
        >
          <a-descriptions-item label="关联知识点">
            <div class="refine-compare-row">
              <div class="refine-compare-col refine-col-original">
                <div class="refine-compare-label">
                  机筛原文
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(handoff?.relatedKnowledge) }}</pre>
              </div>
              <div class="refine-compare-col refine-col-refined">
                <div class="refine-compare-label">
                  教研修缮
                  <a-tag v-if="!isRefineFieldEqual(handoff?.relatedKnowledge, refineResult?.handoff?.relatedKnowledge)" color="green" size="small" style="margin-left: 6px">已优化</a-tag>
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(refineResult?.handoff?.relatedKnowledge) }}</pre>
              </div>
            </div>
          </a-descriptions-item>
          <a-descriptions-item label="教学重点">
            <div class="refine-compare-row">
              <div class="refine-compare-col refine-col-original">
                <div class="refine-compare-label">
                  机筛原文
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(handoff?.knowledgeAnalysis?.teachingFocus) }}</pre>
              </div>
              <div class="refine-compare-col refine-col-refined">
                <div class="refine-compare-label">
                  教研修缮
                  <a-tag v-if="!isRefineFieldEqual(handoff?.knowledgeAnalysis?.teachingFocus, refineResult?.handoff?.knowledgeAnalysis?.teachingFocus)" color="green" size="small" style="margin-left: 6px">已优化</a-tag>
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.teachingFocus) }}</pre>
              </div>
            </div>
          </a-descriptions-item>
          <a-descriptions-item label="关键公式">
            <div class="refine-compare-row">
              <div class="refine-compare-col refine-col-original">
                <div class="refine-compare-label">
                  机筛原文
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(handoff?.knowledgeAnalysis?.keyFormulaList) }}</pre>
              </div>
              <div class="refine-compare-col refine-col-refined">
                <div class="refine-compare-label">
                  教研修缮
                  <a-tag v-if="!isRefineFieldEqual(handoff?.knowledgeAnalysis?.keyFormulaList, refineResult?.handoff?.knowledgeAnalysis?.keyFormulaList)" color="green" size="small" style="margin-left: 6px">已优化</a-tag>
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.keyFormulaList) }}</pre>
              </div>
            </div>
          </a-descriptions-item>
          <a-descriptions-item label="公式提示">
            <div class="refine-compare-row">
              <div class="refine-compare-col refine-col-original">
                <div class="refine-compare-label">
                  机筛原文
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(handoff?.knowledgeAnalysis?.formulaHints) }}</pre>
              </div>
              <div class="refine-compare-col refine-col-refined">
                <div class="refine-compare-label">
                  教研修缮
                  <a-tag v-if="!isRefineFieldEqual(handoff?.knowledgeAnalysis?.formulaHints, refineResult?.handoff?.knowledgeAnalysis?.formulaHints)" color="green" size="small" style="margin-left: 6px">已优化</a-tag>
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(refineResult?.handoff?.knowledgeAnalysis?.formulaHints) }}</pre>
              </div>
            </div>
          </a-descriptions-item>
          <a-descriptions-item label="常见错误">
            <div class="refine-compare-row">
              <div class="refine-compare-col refine-col-original">
                <div class="refine-compare-label">
                  机筛原文
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(handoff?.commonMistakes) }}</pre>
              </div>
              <div class="refine-compare-col refine-col-refined">
                <div class="refine-compare-label">
                  教研修缮
                  <a-tag v-if="!isRefineFieldEqual(handoff?.commonMistakes, refineResult?.handoff?.commonMistakes)" color="green" size="small" style="margin-left: 6px">已优化</a-tag>
                </div>
                <pre class="refine-compare-content">{{ formatRefineField(refineResult?.handoff?.commonMistakes) }}</pre>
              </div>
            </div>
          </a-descriptions-item>
        </a-descriptions>
      </div>
      <div class="refine-modal-footer">
        <a-space>
          <a-button @click="keepOriginalRefine">
            保留原文
          </a-button>
          <a-button
            type="primary"
            @click="applyRefine"
          >
            应用修缮
          </a-button>
        </a-space>
      </div>
    </a-modal>

    <!-- 提示词编辑弹窗 -->
    <a-modal
      v-model:open="promptEditOpen"
      title="提示词设置"
      :width="720"
      @ok="promptEditOpen = false"
    >
      <a-divider orientation="left">
        讲解风格
      </a-divider>
      <a-typography-paragraph type="secondary" style="font-size: 12px;">
        选择不同的讲解风格 Skill，决定老师的人设、讲解节奏和内容侧重。
      </a-typography-paragraph>
      <a-select
        v-model:value="selectedSkillId"
        style="width: 100%;"
        :disabled="state === 'generating'"
      >
        <a-select-option
          v-for="skill in skillList"
          :key="skill.id"
          :value="skill.id"
        >
          {{ skill.name }}
          <template v-if="skill.description">
            <a-typography-text type="secondary" style="font-size: 12px; display: block;">
              {{ skill.description }}
            </a-typography-text>
          </template>
        </a-select-option>
      </a-select>

      <a-divider orientation="left">
        自定义 System Prompt
      </a-divider>
      <a-typography-paragraph type="secondary" style="font-size: 12px;">
        留空使用上方选中的 Skill 默认 Prompt；粘贴自定义 Prompt 后，点击生成即生效（优先级高于 Skill）。
      </a-typography-paragraph>
      <a-textarea
        v-model:value="customSystemPrompt"
        :rows="16"
        placeholder="留空使用默认 System Prompt"
        :disabled="state === 'generating'"
      />
      <div style="margin-top: 8px; display: flex; justify-content: space-between; align-items: center;">
        <a-typography-text type="secondary" style="font-size: 12px;">
          {{ customSystemPrompt.length }} 字 · 当前使用：{{ currentSkillName }}
        </a-typography-text>
        <a-space>
          <a-button size="small" :disabled="!customSystemPrompt" @click="customSystemPrompt = ''">
            清空自定义
          </a-button>
        </a-space>
      </div>
    </a-modal>
  </a-layout>
</template>

<style scoped>
/* 画布参数面板 */
.canvas-params-bar {
  padding: 8px 12px;
  margin-bottom: 12px;
  background: #fafafa;
  border: 1px solid #e8e8e8;
  border-radius: 6px;
}

.canvas-params-bar :deep(.ant-input-number) {
  font-size: 12px;
}

.canvas-params-bar :deep(.ant-select) {
  font-size: 12px;
}

.params-label {
  font-weight: 600;
  color: #1677ff;
  font-size: 12px;
}

/* board 单元格 */
.board-cell {
  min-height: 40px;
  min-width: 0;
  cursor: text;
}

.board-rendered {
  padding: 4px 6px;
  font-size: 13px;
  line-height: 1.6;
  color: #262626;
  white-space: pre-wrap;
  word-break: break-word;
  min-height: 32px;
}

.board-rendered:hover {
  background: #f0f7ff;
  border-radius: 4px;
}

/* board 起手坐标：小字号浅灰色 */
.board-coord {
  font-size: 10px;
  color: #bfbfbf;
  line-height: 1.2;
  margin-bottom: 2px;
  font-family: monospace;
}

/* board 编辑区域：startCoord 输入框 + content textarea */
.board-edit-wrap {
  padding: 4px 6px;
}

/* KaTeX 样式微调 */
.board-rendered :deep(.katex) {
  font-size: 1.1em;
}

.board-rendered :deep(.katex-display) {
  margin: 4px 0;
}

/* 表格优化 */
:deep(.ant-table) {
  font-size: 12px;
}

:deep(.ant-table-tbody > tr > td) {
  padding: 6px 8px;
}

:deep(.ant-table-thead > tr > th) {
  padding: 8px;
  font-size: 12px;
  font-weight: 600;
}

.knowledge-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
  margin-top: 11px;
}

.knowledge-chip {
  margin: 0;
  padding: 3px 11px;
  border-radius: 999px;
  cursor: pointer;
  transition: transform 0.15s ease, box-shadow 0.15s ease;
}

.knowledge-chip:hover {
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(22, 119, 255, 0.16);
}

.knowledge-detail-table :deep(.ant-descriptions-item-label) {
  width: 132px;
  color: #49627c;
  background: #f6faff;
}

.qh-check-empty {
  display: flex;
  align-items: center;
  gap: 14px;
  padding: 22px 4px;
  color: #1677ff;
  font-size: 20px;
}

.qh-check-empty p {
  margin: 4px 0 0;
  color: #666;
  font-size: 12px;
}

.qh-check-change {
  width: 100%;
}

.qh-check-diff {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: 10px;
  margin-top: 10px;
}

.qh-check-diff > div {
  min-width: 0;
  padding: 10px 12px;
  border: 1px solid #e8e8e8;
  border-radius: 6px;
  background: #fafafa;
}

.qh-check-diff > div:last-child {
  border-color: #b7ebc6;
  background: #f6ffed;
}

.qh-check-diff span {
  color: #8c8c8c;
  font-size: 11px;
}

.qh-check-diff p {
  margin: 5px 0 0;
  color: #262626;
  font-size: 12px;
  line-height: 1.6;
  white-space: pre-wrap;
  overflow-wrap: anywhere;
}

@media (max-width: 720px) {
  .qh-check-diff {
    grid-template-columns: 1fr;
  }
}

.refine-compare-row {
  display: flex;
  gap: 12px;
}
.refine-compare-col {
  flex: 1;
  min-width: 0;
}
.refine-compare-label {
  font-size: 12px;
  color: #8c8c8c;
  margin-bottom: 4px;
}
.refine-col-original .refine-compare-label {
  color: #8c8c8c;
}
.refine-col-refined .refine-compare-label {
  color: #52c41a;
  font-weight: 500;
}
.refine-col-original .refine-compare-content {
  background: #fafafa;
  border: 1px solid #f0f0f0;
}
.refine-col-refined .refine-compare-content {
  background: #f6ffed;
  border: 1px solid #b7eb8f;
}
.refine-compare-content {
  padding: 8px 10px;
  border-radius: 4px;
  white-space: pre-wrap;
  word-break: break-all;
  margin: 0;
  font-size: 13px;
  line-height: 1.6;
  max-height: 200px;
  overflow-y: auto;
}
.refine-modal-footer {
  text-align: right;
  margin-top: 16px;
}

.qh-section-title {
  font-size: 11px;
  font-weight: 600;
  color: #8c8c8c;
  margin: 16px 0 8px;
  letter-spacing: 0.08em;
  text-transform: uppercase;
}
.qh-section-title:first-of-type {
  margin-top: 0;
}

.qh-field-key {
  font-size: 8px;
  color: #bbb;
  margin-left: 4px;
  font-family: monospace;
}
</style>
