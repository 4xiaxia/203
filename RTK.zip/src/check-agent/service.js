import { getCheckAgentApiSnapshot } from '../lib/checkAgentApiConfig.js'

// 调用 Check Agent，返回建议结果（不自动应用）
export async function checkAgentRows({ rows } = {}) {
  const userSnap = getCheckAgentApiSnapshot()
  if (!userSnap.apiKey || !userSnap.endpoint || !userSnap.model) {
    throw new Error('Check Agent API 配置不完整')
  }
  if (!/^https?:\/\/.+\/chat\/completions\/?$/i.test(userSnap.endpoint)) {
    throw new Error('Check Agent 接口地址必须是完整 Chat Completions URL')
  }

  const body = {
    endpoint: userSnap.endpoint,
    model: userSnap.model,
    apiKey: userSnap.apiKey,
  }
  if (Array.isArray(rows) && rows.length) {
    body.currentRows = rows
  }

  const controller = new AbortController()
  const timeoutId = window.setTimeout(() => controller.abort(), 95000)
  let response
  let data
  try {
    response = await fetch('/api/check-agent/check', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal,
      body: JSON.stringify(body),
    })
    data = await response.json().catch(() => ({}))
  } catch (error) {
    if (error?.name === 'AbortError') throw new Error('Check Agent 请求超时', { cause: error })
    throw error
  } finally {
    window.clearTimeout(timeoutId)
  }

  if (!response.ok || !data.ok) throw new Error(data.error || `Check Agent 失败 ${response.status}`)
  return {
    rows: data.rows,
    changes: Array.isArray(data.changes) ? data.changes : [],
    model: data.model || userSnap.model,
    usage: data.usage || null,
    checkStatus: data.checkStatus || 'ok',
    checkError: data.checkError || null,
  }
}

// 应用 Check 结果：把修改后的 rows 写回文件
export async function applyCheckResult(rows) {
  if (!Array.isArray(rows) || !rows.length) throw new Error('没有可应用的 rows')
  const response = await fetch('/api/check-agent/apply', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ rows }),
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok || !data.ok) throw new Error(data.error || '应用 Check 结果失败')
  return data
}

// 还原到 Check 之前的原始版本
export async function revertCheckResult() {
  const response = await fetch('/api/check-agent/revert', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  })
  const data = await response.json().catch(() => ({}))
  if (!response.ok || !data.ok) throw new Error(data.error || '还原失败')
  return data
}
