<script setup>
/* 全屏画布预览页
 * URL 参数：
 *   - problemText: 题目文本（URL 编码）
 *   - showGrid: 1=显示网格
 *   - showLabels: 1=显示四标签
 *   - showZones: 1=显示分区辅助线
 *   - sourceImage: 原题图片 URL（URL 编码）
 *   - keepOriginal: 1=保留原题图片
 */
import { computed, defineAsyncComponent, onBeforeUnmount, onMounted, ref } from 'vue'
const RealBoardPreview = defineAsyncComponent(() => import('../components/RealBoardPreview.vue'))
import {
  isLiveBoardPreviewUpdate,
  loadLiveBoardPreview,
} from './liveBoardPreview.js'
import {
  CANVAS_W as DESIGN_W,
  CANVAS_H as DESIGN_H,
} from '../utils/canvasCoords'

const params = new URLSearchParams(window.location.search)
const liveState = loadLiveBoardPreview()

const problemText = ref(liveState?.problemText ?? params.get('problemText') ?? '')
const topicLayout = ref(liveState?.topicLayout || null)
const boardPlan = ref(liveState?.boardPlan || null)
const showGrid = ref(typeof liveState?.showGrid === 'boolean' ? liveState.showGrid : params.get('showGrid') === '1')
const showLabels = ref(typeof liveState?.showLabels === 'boolean' ? liveState.showLabels : params.get('showLabels') === '1')
const showZones = ref(typeof liveState?.showZones === 'boolean' ? liveState.showZones : params.get('showZones') === '1')
const sourceImageUrl = ref(liveState?.sourceImageUrl ?? params.get('sourceImage') ?? '')
const keepOriginal = ref(typeof liveState?.keepOriginal === 'boolean' ? liveState.keepOriginal : params.get('keepOriginal') === '1')

// 工具栏显示控制
const showToolbar = ref(true)
let toolbarTimer = null

function showToolbarTemporarily() {
  showToolbar.value = true
  clearTimeout(toolbarTimer)
  toolbarTimer = setTimeout(() => {
    showToolbar.value = false
  }, 2500)
}

function applyLiveState(state) {
  if (!state) return
  problemText.value = state.problemText || ''
  topicLayout.value = state.topicLayout || null
  boardPlan.value = state.boardPlan || null
  sourceImageUrl.value = state.sourceImageUrl || ''
  keepOriginal.value = Boolean(state.keepOriginal)
  showGrid.value = Boolean(state.showGrid)
  showLabels.value = Boolean(state.showLabels)
  showZones.value = Boolean(state.showZones)
}

function onStorage(event) {
  if (isLiveBoardPreviewUpdate(event)) applyLiveState(loadLiveBoardPreview())
}

onMounted(() => {
  showToolbarTemporarily()
  window.addEventListener('storage', onStorage)
})

onBeforeUnmount(() => {
  clearTimeout(toolbarTimer)
  window.removeEventListener('storage', onStorage)
})

const aspectRatio = computed(() => `${DESIGN_W} / ${DESIGN_H}`)
</script>

<template>
  <div class="fullscreen-board" @mousemove="showToolbarTemporarily" @mouseleave="showToolbar = false">
    <!-- 画布主体 -->
    <div class="board-stage">
      <RealBoardPreview
        :problem-text="problemText"
        :topic-layout="topicLayout"
        :board-plan="boardPlan"
        :show-grid="showGrid"
        :show-all-labels="showLabels"
        :show-zone-guides="showZones"
        :source-image-url="sourceImageUrl"
        :keep-original="keepOriginal"
        :interactive="false"
      />
    </div>

    <!-- 悬浮工具栏 -->
    <transition name="fade">
      <div v-if="showToolbar" class="toolbar">
        <label>
          <input type="checkbox" v-model="showGrid" />
          网格
        </label>
        <label>
          <input type="checkbox" v-model="showLabels" />
          四标签
        </label>
        <label>
          <input type="checkbox" v-model="showZones" />
          分区线
        </label>
        <span class="sep"></span>
        <span class="info">{{ DESIGN_W }} × {{ DESIGN_H }}</span>
      </div>
    </transition>

    <!-- ESC 提示 -->
    <div class="hint-text">移动鼠标显示工具栏 · ESC 退出</div>
  </div>
</template>

<style scoped>
.fullscreen-board {
  position: fixed;
  inset: 0;
  background: #ffffff;
  display: flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
}

.board-stage {
  width: 100%;
  height: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 24px;
  box-sizing: border-box;
}

.board-stage :deep(.real-board-wrap) {
  width: auto;
  height: 100%;
  max-width: 100%;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* 覆盖 RealBoardPreview 的宽度限制，让它按高度自适应撑满 */
.board-stage :deep(.board) {
  width: auto;
  height: 100%;
  max-width: 100%;
  max-height: 100%;
  --board-preview-max: none;
  aspect-ratio: v-bind(aspectRatio);
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.4);
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.toolbar {
  position: fixed;
  top: 20px;
  left: 50%;
  transform: translateX(-50%);
  background: rgba(15, 23, 42, 0.9);
  color: #e2e8f0;
  padding: 10px 18px;
  border-radius: 999px;
  display: flex;
  align-items: center;
  gap: 16px;
  font-size: 13px;
  backdrop-filter: blur(10px);
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.35);
  z-index: 100;
}

.toolbar label {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  user-select: none;
}

.toolbar label input {
  cursor: pointer;
}

.toolbar .sep {
  width: 1px;
  height: 16px;
  background: rgba(255, 255, 255, 0.15);
}

.toolbar .info {
  color: #94a3b8;
  font-size: 12px;
  font-variant-numeric: tabular-nums;
}

.hint-text {
  position: fixed;
  bottom: 16px;
  left: 50%;
  transform: translateX(-50%);
  color: rgba(148, 163, 184, 0.5);
  font-size: 12px;
  pointer-events: none;
}

.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.25s ease;
}

.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
